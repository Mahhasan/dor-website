@extends('layouts.master')
@section('content')
<section class="gallery bg-gray">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h3>Microprocessor Interfacing Laboratory</h3>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection