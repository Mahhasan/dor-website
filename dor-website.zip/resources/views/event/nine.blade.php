@extends('layouts.master')
@section('content')
<section class="cta">
    <div class="container">
        <div class="row">
            <div class="panel panel-primary">
                <div class="panel-heading" style="font-family:Century Gothic;">
                    <b>Webinar on: Students' Engagement and Opportunities in Research & Publications at DIU</b>
                </div>
                <div class="panel-body" style="text-align: center;">
                    <iframe src="https://drive.google.com/file/d/1RBlXNcwS9FeUF3zcRZItUgICpu_sstAR/preview" width="560" height="315" allow="autoplay"></iframe>
                    <h3>Webinar on: Students' Engagement and Opportunities in Research & Publications at DIU</h3>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
