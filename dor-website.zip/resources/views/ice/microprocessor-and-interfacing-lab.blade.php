@extends('layouts.master')
@section('content')
<section class="gallery bg-gray">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h3>Microprocessor and Interfacing Lab</h3>
                    <b>Assigned Person Details</b><br>
                    <b>Md. Taslim Arefin</b><br>
                    <b>Associate Professor and Head</b><br>
                    <p><i class="fa fa-phone" aria-hidden="true"></i> <a href="tel:+8801713493075">+8801713493075</a>&nbsp;&nbsp;<i class="fa fa-envelope" aria-hidden="true"></i> <a href = "mailto: arefin@daffodilvarsity.edu.bd">arefin@daffodilvarsity.edu.bd</a> </p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/cf696544ec6c551b53b0f42daa5930e3.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/cf696544ec6c551b53b0f42daa5930e3.webp"></a>
                    <p></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/29879cde2756fdde688a9bf6f1129a8d.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/29879cde2756fdde688a9bf6f1129a8d.webp"></a>
                    <p></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/4ad3d6f050c1dabe1f25a95cd65a482c.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/4ad3d6f050c1dabe1f25a95cd65a482c.webp"></a>
                    <p></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/7c29726d459cb2d63013dcf8fa6757a9.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/7c29726d459cb2d63013dcf8fa6757a9.webp"></a>
                    <p></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/04fb889f1cca0530cfcf8f97f88b623b.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/04fb889f1cca0530cfcf8f97f88b623b.webp"></a>
                    <p></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/b94a83fc1f78d60b0a030a0a8f696879.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/b94a83fc1f78d60b0a030a0a8f696879.webp"></a>
                    <p></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/c152a4769a8de069131562713a56b010.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/c152a4769a8de069131562713a56b010.webp"></a>
                    <p></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/ea939480b071d22360d3466473229682.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/ea939480b071d22360d3466473229682.webp"></a>
                    <p></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/d340d11e5658a8636d92b3ba4b1582f1.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/d340d11e5658a8636d92b3ba4b1582f1.webp"></a>
                    <p></p>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection