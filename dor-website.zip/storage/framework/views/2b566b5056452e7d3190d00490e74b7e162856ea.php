<?php $__env->startSection('content'); ?>
<section class="cta" style="margin-bottom: 180px">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Sl.No</th>
                                <th scope="col">Topic</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($resources)): ?>
                                <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e(+$key); ?></th>
                                        <td><a href="<?php echo e(route('about-resource-details', $resource->id)); ?>" target="_blank"><?php echo e($resource->topic); ?></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/frontend/resources.blade.php ENDPATH**/ ?>