<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title> Division of Research </title>
        <!-- mobile responsive meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <!--Favicon-->
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
        <!-- Slick Carousel -->
        <link rel="stylesheet" href="<?php echo e(asset('js/slick/slick.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('js/slick/slick-theme.css')); ?>">
        <!-- FancyBox -->
        <link rel="stylesheet" href="<?php echo e(asset('js/fancybox/jquery.fancybox.min.css')); ?>">
        <link src="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" rel="stylesheet">
        <!-- Stylesheets -->
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
        
    </head>
    <body>
        <div class="page-wrapper">
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>

            
        </div>
        <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
        <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/slick/slick.min.js')); ?>"></script>
        <!-- FancyBox -->
        <script src="<?php echo e(asset('js/fancybox/jquery.fancybox.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/validate.js')); ?>"></script>
        <script src="<?php echo e(asset('js/wow.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
        <script src="<?php echo e(asset('js/script.js')); ?>"></script>
        <script src="<?php echo e(asset('js/mouse.js')); ?>"></script>
    </body>

</html>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dor-website\resources\views/layouts/master.blade.php ENDPATH**/ ?>