
<?php $__env->startSection('content'); ?>
<section class="gallery bg-gray">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $sciencediscipline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <div class="section-title text-center">
                        <h3><?php echo e($discipline->lab_name); ?></h3>
                        <?php if($discipline->person_name): ?>
                            <b>Assigned Person Details</b><br>
                            <b><?php echo e($discipline->person_name); ?></b><br>
                        <?php endif; ?>
                        <b><?php echo e($discipline->designation); ?></b><br>
                        <p><i class="fa fa-phone" aria-hidden="true"></i> <a href="tel: 0<?php echo e($discipline->cell); ?>"><?php echo e($discipline->cell); ?></a>&nbsp;&nbsp;<i class="fa fa-envelope" aria-hidden="true"></i> <a href = "mailto: <?php echo e($discipline->email); ?>"><?php echo e($discipline->email); ?></a> </p>
                    </div>
                </div>
                <?php if($discipline->picture): ?>
                    <?php $__currentLoopData = json_decode($discipline->picture, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-sm-6">
                            <div class="gallery-item">
                                <img src="<?php echo e(asset('uploads/interdisciplinary_research/' . $picture)); ?>" alt="" class="img-responsive" width="100%" height="300">
                                <a data-fancybox="images" href="<?php echo e(asset('uploads/interdisciplinary_research/' . $picture)); ?>"></a>
                                <p><?php echo e($discipline->lab_name); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    No Images Available
                <?php endif; ?>
                <?php if($discipline->image_links): ?>
                    <?php $__currentLoopData = json_decode($discipline->image_links, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="gallery-item">
                                <img src="<?php echo e($link); ?>" alt="" class="img-responsive" width="100%" height="300">
                                <a data-fancybox="images" href="<?php echo e($link); ?>"></a>
                                <p><?php echo e($discipline->lab_name); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/frontend/science_discipline_details.blade.php ENDPATH**/ ?>