
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($websiteSlider)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Create New Slider">Create New Slider</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($websiteSlider) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <?php if(isset($websiteSlider)): ?>
                <h6>Edit Slider Image</h6>
                <form method="POST" action="<?php echo e(route('website.slider.update', $websiteSlider->id)); ?>" enctype="multipart/form-data">
                    <?php echo method_field('PATCH'); ?>
            <?php else: ?>
                <h6>Add New Slider Image</h6>
                <form method="POST" action="<?php echo e(route('website.slider.store')); ?>" enctype="multipart/form-data">
            <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container col-md-6 mb-4">
                        <input type="number" class="input" id="slider_serial" name="slider_serial" value="<?php echo e(old('slider_serial', isset($websiteSlider) ? $websiteSlider->slider_serial : '')); ?>" required placeholder=" ">
                        <div class="cut"></div>
                        <label for="slider_serial" class="placeholder">Slider Serial <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-md-6 mb-4">
                        <input type="file" class="input border-0 pt-2" id="picture" name="picture" accept="image/*" <?php echo e(isset($websiteSlider) ? '' : 'required'); ?> placeholder=" ">
                        <?php if(isset($websiteSlider) && $websiteSlider->picture): ?>
                            <div class="mr-2 mt-3 float-right">
                                <img src="<?php echo e(asset('uploads/website_slider/' . $websiteSlider->picture)); ?>" alt="Image" height="auto" width="200">
                            </div>
                        <?php endif; ?>   
                        <div class="cut"></div>
                        <label for="picture" class="placeholder">Slider Image <small class="font-italic">(size: 1920 x 650 px)</small> <span class="text-danger">*</span></label>
                    </div>
                </div>
                <?php if(isset($websiteSlider)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('website.slider.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="mx-auto  mb-5">
        <h5 class="text-center pt-5">Website Slider Records</h5>
        <hr>
    </div>

    <div class="row mb-5">
        <?php $__currentLoopData = $websiteSliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $websiteSlider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 mb-4 mx-auto">
                <div class="card">
                    <?php if($websiteSlider->picture): ?>
                        <img src="<?php echo e(asset('uploads/website_slider/' . $websiteSlider->picture)); ?>" class="card-img-top" alt="Image">
                    <?php else: ?>
                        <img src="<?php echo e(asset('path_to_default_image.jpg')); ?>" class="card-img-top" alt="No Image Available">
                    <?php endif; ?>
                    <div class="card-body p-1">
                        <div class="text-center">
                            <a href="<?php echo e(route('website.slider.edit', $websiteSlider->id)); ?>" class="btn btn-sm text-primary"><i class="fas fa-edit"></i></a>
                            <form action="<?php echo e(route('website.slider.destroy', $websiteSlider->id)); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm text-danger" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fa fa-trash"></i></button>
                            </form>
                            <button type="button" class="btn btn-sm <?php echo e($websiteSlider->is_visible ? 'btn-success' : 'btn-danger'); ?>" id="visibilityButton<?php echo e($websiteSlider->id); ?>" onclick="toggleVisibility(<?php echo e($websiteSlider->id); ?>)">
                                <?php echo e($websiteSlider->is_visible ? 'Visible' : 'Invisible'); ?>

                            </button>
                            <small class="float-right pt-2 pr-2">Slider-<?php echo e($websiteSlider->slider_serial); ?></small>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/backend/website_slider.blade.php ENDPATH**/ ?>