<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Scopus Indexed Publications
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <div>
                            <h4>Paper Details </h4>
                        </div>
                        <hr>
                        <dl class="row">
                            <dt class="col-sm-2">Title</dt>
                            <dd class="col-sm-10" style="margin-left: 135px;margin-top: -20px;">
                                <?php echo e($responseBody->name); ?></dd>
                        </dl>
                        <dl class="row">
                            <dt class="col-sm-2">Author</dt>
                            <dd class="col-sm-10" style="margin-left: 135px;margin-top: -20px;">
                                <?php echo e(str_replace( array("="), '', $responseBody->first_author)); ?>,
                                <?php $__currentLoopData = $responseBody->co_authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($value->name); ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </dd>
                        </dl>
                        <dl class="row">
                            <dt class="col-sm-2">Email</dt>
                            <dd class="col-sm-10" style="margin-left: 135px;margin-top: -20px;">
                                <?php echo e($responseBody->email); ?></dd>
                        </dl>
                        <dl class="row">
                            <dt class="col-sm-2">Abstract</dt>
                            <dd class="col-sm-10"
                                style="margin-left: 135px;margin-top: -20px;text-align:justify;">
                                <?php echo $responseBody->abstract; ?></dd>
                        </dl>
                        <dl class="row">
                            <dt class="col-sm-2">Keywords</dt>
                            <dd class="col-sm-10" style="margin-left: 135px;margin-top: -20px;">
                                <?php echo e(str_replace( array(".>"), '', $responseBody->keywords)); ?></dd>
                        </dl>


                        <dl class="row">
                            <dt class="col-sm-2">Journal or Conference Name</dt>
                            <dd class="col-sm-10" style="margin-left: 135px;margin-top: -20px;"> <a
                                    href="<?php echo e($responseBody->cj_link); ?>"><?php echo e(str_replace( array("@","#"), '', $responseBody->cj_name)); ?></a>
                            </dd>
                        </dl>
                        <dl class="row">
                            <dt class="col-sm-2">Publication Year</dt>
                            <dd class="col-sm-10" style="margin-left: 135px;margin-top: -20px;">
                                <?php echo e($responseBody->publication_year); ?></dd>
                        </dl>
                        <dl class="row">
                            <dt class="col-sm-2">Indexing</dt>
                            <dd class="col-sm-10" style="margin-left: 135px;margin-top: -20px;">
                                <?php echo e($responseBody->indexed); ?></dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dor-website\resources\views/scopus_article_details.blade.php ENDPATH**/ ?>