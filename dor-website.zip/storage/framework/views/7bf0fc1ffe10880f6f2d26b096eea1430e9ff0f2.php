<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title> Division of Research </title>

  
  <!-- mobile responsive meta -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
  <!-- Slick Carousel -->
  <link rel="stylesheet" href="<?php echo e(asset('js/slick/slick.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('js/slick/slick-theme.css')); ?>">
  <!-- FancyBox -->
  <link rel="stylesheet" href="<?php echo e(asset('js/fancybox/jquery.fancybox.min.css')); ?>">
  
  <!-- Stylesheets -->
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  
  <!--Favicon-->
  <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
  <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v4.0"></script>
</head>
<body>

<div class="page-wrapper">
      <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="cta">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <h3 class="text-center">FSIT Research Ethics Committee</h3><br>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Sl. No</th>
                                <th scope="col">Name & Designation</th>
                                <th scope="col">Position</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td>Professor Dr. Md. Ismail Jabiullah, CSE</td>
                                <td>Convener</td>
                            </tr>
                            <tr>
                                <th scope="row">2</th>
                                <td>Dr. Sk. Abdul Kader Arafin, Associate Professor, GED</td>
                                <td>Member</td>
                            </tr>
                            <tr>
                                <th scope="row">3</th>
                                <td>Dr. Mahfuza Parveen, Associate Professor, ESDM</td>
                                <td>Member</td>
                            </tr>
                            <tr>
                                <th scope="row">4</th>
                                <td>Dr. Sumit Kumar Banshal, Assistant Professor, CSE</td>
                                <td>Member</td>
                            </tr>
                            <tr>
                                <th scope="row">5</th>
                                <td>Dr. Md. Samaun Hasan, Assistant Professor, MCT</td>
                                <td>Member</td>
                            </tr>
                            <tr>
                                <th scope="row">6</th>
                                <td>Ms. Afsana Begum, Assistant Professor, SWE</td>
                                <td>Member</td>
                            </tr>
                            <tr>
                                <th scope="row">7</th>
                                <td>Ms. Nayeema Rahman, Lecturer (Senior Scale), CIS</td>
                                <td>Member</td>
                            </tr>
                            <tr>
                                <th scope="row">8</th>
                                <td>Mr. Khalid Been Badruzzaman Biplob, Lecturer (Senior Scale), SWE</td>
                                <td>Member Secretary</td>
                            </tr>
                            
                           
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

</div>
<script src="<?php echo e(asset('js/modernizr-2.6.2-respond-1.1.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script> -->
<!-- Slick Slider -->
<script src="<?php echo e(asset('js/slick/slick.min.js')); ?>"></script>
<!-- FancyBox -->
<script src="<?php echo e(asset('js/fancybox/jquery.fancybox.min.js')); ?>"></script>
<!-- Google Map -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script>
<script src="<?php echo e(asset('js/google-map/gmap.js')); ?>"></script>

<script src="<?php echo e(asset('js/validate.js')); ?>"></script>
<script src="<?php echo e(asset('js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>

</html>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/research-ethics-committee-fsit.blade.php ENDPATH**/ ?>