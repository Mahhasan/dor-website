<?php $__env->startSection('content'); ?>
<section class="video-gallery">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h3>Video Gallery</h3>
                </div>
            </div>
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($video->video_links): ?>
                    <?php $__currentLoopData = json_decode($video->video_links, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videoLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="video-gallery-item">
                                <div class="video-iframe">
                                    <iframe width="100%" height="350" allow="autoplay" src="<?php echo e($videoLink); ?>" frameborder="0" allowfullscreen></iframe>
                                    <h3><?php echo e($video->title); ?> - <?php echo e($video->year); ?></h3>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    No Videos Available
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/frontend/video.blade.php ENDPATH**/ ?>