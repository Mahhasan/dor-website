<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title> Division of Research </title>

  
  <!-- mobile responsive meta -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
  <!-- Slick Carousel -->
  <link rel="stylesheet" href="<?php echo e(asset('js/slick/slick.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('js/slick/slick-theme.css')); ?>">
  <!-- FancyBox -->
  <link rel="stylesheet" href="<?php echo e(asset('js/fancybox/jquery.fancybox.min.css')); ?>">
  
  <!-- Stylesheets -->
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <!--Favicon-->
  <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
  <link rel="icon" href="images/favicon.ico" type="image/x-icon">
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v4.0"></script>
</head>

<body>
  <div class="page-wrapper">
    <!-- Preloader -->
    <!-- <div class="preloader"></div> -->
    <!-- Preloader -->


<!--header top-->

<!--Header Upper-->

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Main Header-->

<section class="gallery bg-gray">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h3>Data Science Lab</h3>
                    <b>Assigned Person Details</b><br>
                    <b>Tapushe Rabaya Toma</b><br>
                    <b>Assistant Professor</b><br>
                    <p><i class="fa fa-phone" aria-hidden="true"></i> <a href="tel:01676078744">01676078744</a>&nbsp;&nbsp;<i class="fa fa-envelope" aria-hidden="true"></i> <a href = "mailto: toma.swe@diu.edu.bd">toma.swe@diu.edu.bd</a> </p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/22f4eaddfaf463395a5a4de05eb8d822.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/22f4eaddfaf463395a5a4de05eb8d822.webp"></a>
                    <p></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/2d3b587fe6f38d590585208113fbf9be.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/2d3b587fe6f38d590585208113fbf9be.webp"></a>
                    <p></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="gallery-item">
                    <img src="https://daffodilvarsity.edu.bd/labGallery/fe0aa3415004b9b65d665fa5f3d8a603.webp" class="img-responsive" style="width:360px; height:250px;" alt="gallery-image">
                    <a data-fancybox="images" href="https://daffodilvarsity.edu.bd/labGallery/fe0aa3415004b9b65d665fa5f3d8a603.webp"></a>
                    <p></p>
                </div>
            </div>
        </div>
    </div>
</section>



<!--End footer-main-->

</div>
<!--End pagewrapper-->


<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".header-top">
  <span class="icon fa fa-angle-up">dd</span>
</div>

<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
<!-- Slick Slider -->
<script src="<?php echo e(asset('js/slick/slick.min.js')); ?>"></script>
<!-- FancyBox -->
<script src="<?php echo e(asset('js/fancybox/jquery.fancybox.min.js')); ?>"></script>
<!-- Google Map -->
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script> 
<script src="<?php echo e(asset('js/google-map/gmap.js')); ?>"></script>
-->
<script src="<?php echo e(asset('js/validate.js')); ?>"></script>
<script src="<?php echo e(asset('js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>

</html>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/swe/data-science-lab.blade.php ENDPATH**/ ?>