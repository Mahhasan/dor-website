<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
        <div class="row">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">Sl. No</th>
                        <th scope="col">Faculty Name</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td><a href="<?php echo e(url('/research-ethics-committee-fsit')); ?>" target="_blank">FSIT Research Ethics Committee</a></td>
                    </tr>
                    <tr>
                        <th scope="row">2</th>
                        <td><a href="<?php echo e(url('research-ethics-committee-fbe')); ?>" target="_blank">FBE Research Ethics Committee</a></td>
                    </tr>
                    <tr>
                        <th scope="row">3</th>
                        <td><a>FAHS Research Ethics Committee</a></td>
                    </tr>
                    <tr>
                        <th scope="row">4</th>
                        <td><a href="<?php echo e(url('/research-ethics-committee-fe')); ?>" target="_blank">FE Research Ethics Committee</a></td>
                    </tr>
                    <tr>
                        <th scope="row">5</th>
                        <td><a href="<?php echo e(url('/research-ethics-committee-fhss')); ?>" target="_blank">FHSS Research Ethics Committee</a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/research-ethics-committee.blade.php ENDPATH**/ ?>