
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($diuJournal)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Add New Journal">Add New Journal</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($diuJournal) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <?php if(isset($diuJournal)): ?>
            <h6>Edit <span class="text-success font-weight-bold"><?php echo e($diuJournal->name); ?>'s</span> Record</h6>
            <form method="POST" action="<?php echo e(route('diu.journals.update', $diuJournal->id)); ?>" enctype="multipart/form-data">
                <?php echo method_field('PATCH'); ?>
                <?php else: ?>
                <h6>Add New Journal</h6>
            <form method="POST" action="<?php echo e(route('diu.journals.store')); ?>" enctype="multipart/form-data">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="name" name="name" value="<?php echo e(old('name', isset($diuJournal) ? $diuJournal->name : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="name" class="placeholder">Name <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="url" class="input" id="link" name="link" value="<?php echo e(old('link', isset($diuJournal) ? $diuJournal->link : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="link" class="placeholder">Website Link <span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-sm-12 mb-4">
                        <input type="file" class="input border-0 pt-2" id="picture" name="picture" accept="image/*" <?php echo e(isset($diuJournal) ? '' : 'required'); ?> placeholder=" ">
                        <?php if(isset($diuJournal) && $diuJournal->picture): ?>
                            <div class="mr-2 mt-3 float-right">
                                <img src="<?php echo e(asset('uploads/diu_journal/' . $diuJournal->picture)); ?>" alt="Image" height="auto" width="300">
                            </div>
                        <?php endif; ?>   
                        <div class="cut"></div>
                        <label for="picture" class="placeholder">Journal Banner<small class="font-italic"> (size: 300 x 150 px)</small> <span class="text-danger">*</span></label>
                    </div>
                </div>
                <?php if(isset($diuJournal)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('diu.journals.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="mx-auto mt-5 mb-5">
        <h5 class="text-center pt-5">DIU Journals</h5>
        <hr>
    </div>

    <div class="row mb-5">
        <?php $__currentLoopData = $diuJournals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diuJournal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 mb-4 mx-auto">
                <div class="card">
                    <?php if($diuJournal->picture): ?>
                        <img src="<?php echo e(asset('uploads/diu_journal/' . $diuJournal->picture)); ?>" alt="<?php echo e($diuJournal->name); ?> Image">
                    <?php else: ?>
                        No Image Available
                    <?php endif; ?>
                    <a href="<?php echo e($diuJournal->link); ?>" target="_blank" class="text-center p-2"><?php echo e($diuJournal->name); ?></a>
                    <div class="card-body p-0">
                        <div class="text-center">
                            <a href="<?php echo e(route('diu.journals.edit', $diuJournal->id)); ?>" class="btn btn-sm text-primary"><i class="fas fa-edit fa-sm"></i></a>
                            <form action="<?php echo e(route('diu.journals.destroy', $diuJournal->id)); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm text-danger" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/backend/diu_journal.blade.php ENDPATH**/ ?>