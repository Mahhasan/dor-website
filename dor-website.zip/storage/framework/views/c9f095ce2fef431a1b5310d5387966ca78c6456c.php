<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
        <?php $__currentLoopData = $directorMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$directorMessage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row p-4 bg" style="background-color:#f2f2f2">
                <h4 class="text-center pb-5" style="font-family: Century Gothic;"><?php echo e($directorMessage->title); ?></h4>
                <p>
                    <?php if($directorMessage->picture): ?>
                        <img class="d-block mx-auto" src="<?php echo e(asset('uploads/director_message/' . $directorMessage->picture)); ?>"alt="">
                    <?php else: ?>
                        <img src="<?php echo e(asset('path_to_default_image.jpg')); ?>" class="card-img-top" alt="">
                    <?php endif; ?>
                </p>
                <p><?php echo $directorMessage->message; ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/frontend/director_message.blade.php ENDPATH**/ ?>