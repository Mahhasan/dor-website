<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title> Division of Research </title>

  
  <!-- mobile responsive meta -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
  <!-- Slick Carousel -->
  <link rel="stylesheet" href="<?php echo e(asset('js/slick/slick.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('js/slick/slick-theme.css')); ?>">
  <!-- FancyBox -->
  <link rel="stylesheet" href="<?php echo e(asset('js/fancybox/jquery.fancybox.min.css')); ?>">
  
  <!-- Stylesheets -->
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  
  <!--Favicon-->
  <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
  <link rel="icon" href="images/favicon.ico" type="image/x-icon">
  <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v4.0"></script>
<style>
body{
    font-family:Century Gothic;
}
    .center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}
</style>
</head>
<body>

<div class="page-wrapper">
    
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="cta">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row" >
                <div class="panel panel-primary">
                            <div class="panel-heading" style="font-family:Century Gothic;"><b>
Workshop on Enhancement of Research among the faculty members of GED</b>
</div>
                            <div class="panel-body">
                                <img src="<?php echo e(url('images/event/fourteen.png')); ?>" class="center">
                            <p style="font-family:Century Gothic; font-size: 15px; padding-top: 15px;" >The Department of General Educational Development (GED) organized a workshop on Enhancement of Research among the faculty members of GED on 24 January, 2019 at DIU main campus, room no. 308. Each faculty member presented their research interest, research network, collaboration of research, number of publication in 2018, and their expected number of publications in 2019. Moreover, the faculty members have promised to publish 68 articles in Scopus indexed journals in 2019. </p>
                            <p style="font-family:Century Gothic; font-size: 15px;">Professor Yousuf Mahbubul Islam, PhD, Vice Chancellor of Daffodil International University had motivated the faculty members to conduct quality research at the end of the workshop. Professor Dr. Md. Kabirul Islam, Director, Division of Research was also present in the workshop and advised the faculty members regarding the mechanism of research publication. The workshop was conducted by the Research and Development committee of the Department under the supervision of Mr. Syed Mizanur Rahman, Head of the department of GED.</p>
                            
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>

</div>
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
<!-- Slick Slider -->
<script src="<?php echo e(asset('js/slick/slick.min.js')); ?>"></script>
<!-- FancyBox -->
<script src="<?php echo e(asset('js/fancybox/jquery.fancybox.min.js')); ?>"></script>
<!-- Google Map -->
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script> 
<script src="<?php echo e(asset('js/google-map/gmap.js')); ?>"></script>
-->
<script src="<?php echo e(asset('js/validate.js')); ?>"></script>
<script src="<?php echo e(asset('js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>

</body>

</html>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/event/fourteen.blade.php ENDPATH**/ ?>