<?php $__env->startSection('content'); ?>
<section class="gallery bg-gray">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h3>Photo Gallery </h3>
                </div>
            </div>
            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = json_decode($photo->pictures, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="gallery-item">
                        <img src="<?php echo e(asset('uploads/photos/' . $picture)); ?>" alt="<?php echo e($photo->title); ?> Image" width="100%">
                            <a data-fancybox="images" href="<?php echo e(asset('uploads/photos/' . $picture)); ?>"></a>
                            <p><?php echo e($photo->title); ?> - <?php echo e($photo->year); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = json_decode($photo->links, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="gallery-item">
                        <img src="<?php echo e($link); ?>" alt="<?php echo e($photo->title); ?> Image" width="100%">
                            <a data-fancybox="images" href="<?php echo e($link); ?>"></a>
                            <p><?php echo e($photo->title); ?> - <?php echo e($photo->year); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/frontend/photo.blade.php ENDPATH**/ ?>