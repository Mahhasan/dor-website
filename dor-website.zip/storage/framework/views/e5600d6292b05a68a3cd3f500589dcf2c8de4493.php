
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($researchCoordinator)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Add Research Coordinator">Add Research Coordinator</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($researchCoordinator) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <?php if(isset($researchCoordinator)): ?>
            <h6>Edit <span class="text-success font-weight-bold"><?php echo e($researchCoordinator->name); ?>'s</span> Record</h6>
            <form method="POST" action="<?php echo e(route('research.coordinator.update', $researchCoordinator->id)); ?>" enctype="multipart/form-data">
                <?php echo method_field('PATCH'); ?>
                <?php else: ?>
                <h6>Add Research Coordinator</h6>
            <form method="POST" action="<?php echo e(route('research.coordinator.store')); ?>" enctype="multipart/form-data">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="name" name="name" value="<?php echo e(old('name', isset($researchCoordinator) ? $researchCoordinator->name : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="name" class="placeholder">Name <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="designation" name="designation" value="<?php echo e(old('designation', isset($researchCoordinator) ? $researchCoordinator->designation : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="designation" class="placeholder">Designation <span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="email" class="input" id="email" name="email" value="<?php echo e(old('email', isset($researchCoordinator) ? $researchCoordinator->email : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="email" class="placeholder">Email <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="number" class="input" id="cell" name="cell" value="<?php echo e(old('cell', isset($researchCoordinator) ? $researchCoordinator->cell : '')); ?>" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="cell" class="placeholder">Cell</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-sm-6 mb-4">
                        <select id="faculty_id" class="input bg-white"name="faculty_id" required placeholder=" ">
                            <option value="">Select a Faculty</option>
                            <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($faculty->id); ?>" <?php echo e(isset($researchCoordinator) && $researchCoordinator->faculty_id == $faculty->id ? 'selected' : ''); ?>><?php echo e($faculty->full_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="cut"></div>
                        <label for="faculty_id" class="placeholder">Faculty Name <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <select id="department_id" class="input bg-white"  name="department_id" required placeholder=" ">
                            <option selected disabled>Select a Department</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>" <?php echo e(isset($researchCoordinator) && $researchCoordinator->department_id == $department->id ? 'selected' : ''); ?>><?php echo e($department->full_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="cut"></div>
                        <label for="department_id" class="placeholder">Department Name <span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-12 mb-4">
                        <input type="file" class="input border-0 pt-2" id="picture" name="picture" accept="image/*" <?php echo e(isset($researchCoordinator) && $researchCoordinator->picture ? '' : 'required'); ?>>
                        <?php if(isset($researchCoordinator) && $researchCoordinator->picture): ?>
                        <div class="mr-2 mt-3 float-right">
                            <img src="<?php echo e(asset('uploads/research_coordinator/' . $researchCoordinator->picture)); ?>" alt="Image" height="150" width="150">
                        </div>
                        <?php endif; ?>   
                        <div class="cut"></div>
                        <label for="picture" class="placeholder">Image<small class="font-italic"> (size: 150 x 150 px)</small> <span class="text-danger">*</span></label>
                    </div>
                </div>
                <?php if(isset($researchCoordinator)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('research.coordinator.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="mx-auto mb-5">
        <h5 class="text-center pt-5">Research Coordinator Records</h5>
        <hr>
    </div>

    <div class="row">
        <?php $__currentLoopData = $researchCoordinators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$researchCoordinator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card border-0">
                    <?php if($researchCoordinator->picture): ?>
                        <div class="text-center mt-3">
                            <img src="<?php echo e(asset('uploads/research_coordinator/' . $researchCoordinator->picture)); ?>" class="rounded-circle" alt="<?php echo e($researchCoordinator->name); ?> Image" height="150" width="150">
                        </div>
                    <?php else: ?>
                        No Image Available
                    <?php endif; ?>
                    <div class="text-center p-1">
                        <h5><?php echo e($researchCoordinator->name); ?></h5>
                        <p><?php echo e($researchCoordinator->designation); ?>, <?php echo e($researchCoordinator->departments->short_name ?? ''); ?></p>
                        <p><?php echo e($researchCoordinator->faculties->short_name ?? ''); ?></p>
                        <p><?php echo e($researchCoordinator->email); ?></p>
                        <p><?php echo e($researchCoordinator->cell); ?></p>
                        <div class="float-right">
                            <a href="<?php echo e(route('research.coordinator.edit', $researchCoordinator->id)); ?>" class="btn btn-sm text-primary"><i class="fas fa-edit fa-sm"></i></a>
                            <form action="<?php echo e(route('research.coordinator.destroy', $researchCoordinator->id)); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm text-danger" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/backend/research_coordinator.blade.php ENDPATH**/ ?>