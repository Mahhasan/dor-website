
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($video)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Upload New Video">Upload New Video</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($video) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <?php if(isset($video)): ?>
            <h6>Edit <span class="text-success font-weight-bold"><?php echo e($video->title); ?> - <?php echo e($video->year); ?></span> Record</h6>
            <form method="POST" action="<?php echo e(route('videos.update', $video->id)); ?>" enctype="multipart/form-data">
            <?php echo method_field('PATCH'); ?>
            <?php else: ?>
            <h6>Upload New Video</h6>
            <form method="POST" action="<?php echo e(route('videos.store')); ?>" enctype="multipart/form-data">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container col-md-6 mb-4">
                        <input type="text" class="input" id="title" name="title" value="<?php echo e(old('title', isset($video) ? $video->title : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="title" class="placeholder">Title <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-md-6 mb-4">
                        <select class="input" id="year" name="year" required>
                            <option value="">Select Year</option>
                            <?php
                                $currentYear = date('Y');
                            ?>
                            
                            <?php for($i = $currentYear; $i >= ($currentYear - 40); $i--): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e(old('year', isset($video) && $video->year == $i ? 'selected' : '')); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                        <div class="cut"></div>
                        <label for="year" class="placeholder">Year <span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-sm-12 mb-4">
                        <div class="video-links">
                            <div class="row input-container mb-4">
                                <div class="col-8 col-sm-10">
                                    <input type="url" class="input" name="video_links[]" value="<?php echo e(old('video_links.0', isset($video) ? json_decode($video->video_links, true)[0] : '')); ?>" required placeholder=" "/>
                                    <div class="cut"></div>
                                    <label for="video_links" class="placeholder">Video Link 1 <span class="text-danger">*</span></label>
                                </div>
                                <button type="button" class="col-4 col-sm-2 btn btn-outline-danger remove-video-link" style="display: none;">Remove</button>
                            </div>

                            <?php if(isset($video) && $video->video_links): ?>
                                <?php $__currentLoopData = array_slice(json_decode($video->video_links, true), 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $videoLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row input-container mb-5">
                                        <div class="col-8 col-sm-10">
                                            <input type="url" class="input" name="video_links[]" value="<?php echo e(old('video_links.' . $index, $videoLink)); ?>" placeholder=" "/>
                                            <div class="cut"></div>
                                            <label for="video_links" class="placeholder">Video Link <?php echo e($index + 2); ?></label>
                                        </div>
                                        <button type="button" class="col-4 col-sm-2 btn btn-outline-danger remove-video-link">Remove</button>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-info" id="add-video-link">Add More Video Link</button>
                    </div>
                </div>

                <?php if(isset($video)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('videos.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>
    
    <div class="mx-auto mb-5">
        <h5 class="text-center pt-5">Video Gallery</h5>
    </div>

    <div class="row mb-5">
        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-12 mb-5 mx-auto">
                <div class="card border-0">
                    <div class="pt-3 text-center">
                        <h6 class="font-weight-bold"><?php echo e($video->title); ?></h6>
                        <p>Year: <?php echo e($video->year); ?></p>
                        <a href="<?php echo e(route('videos.edit', $video->id)); ?>" class="btn btn-sm text-primary"><i class="fas fa-edit fa-sm"></i></a>
                        <form action="<?php echo e(route('videos.destroy', $video->id)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm text-danger" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                        </form>
                    </div>
                    <hr>
                    <?php if($video->video_links): ?>
                        <div class="row">
                            <?php $__currentLoopData = json_decode($video->video_links, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videoLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 pb-3 mx-auto">
                                    <div class="video-iframe">
                                        <iframe width="100%" height="300px" src="<?php echo e($videoLink); ?>" frameborder="0" allowfullscreen></iframe>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        No Videos Available
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="float-right">
            <?php echo $videos->links('pagination::bootstrap-5'); ?>

        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        // Initial setup to keep at least one input field
        toggleRemoveButtonVisibility();

        // Add Link button click event
        $('#add-video-link').click(function () {
            var linkField = `
                <div class="row input-container mb-4">
                    <div class="col-8 col-sm-10">
                        <input type="url" class="input" name="video_links[]" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="video_links" class="placeholder">Video Link</label>
                    </div>
                    <button type="button" class="col-4 col-sm-2 btn btn-outline-danger remove-video-link">Remove</button>
                </div>
            `;
            $('.video-links').append(linkField);

            // After adding a new field, update remove button visibility
            toggleRemoveButtonVisibility();
        });

        // Remove Link button click event
        $('.video-links').on('click', '.remove-video-link', function () {
            $(this).closest('.row').remove();

            // After removing a field, update remove button visibility
            toggleRemoveButtonVisibility();
        });

        function toggleRemoveButtonVisibility() {
            // Show the remove button only if there are more than one input fields
            $('.remove-video-link').toggle($('.video-links .row').length > 1);
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/backend/videos.blade.php ENDPATH**/ ?>