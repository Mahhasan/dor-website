<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
        <?php $__currentLoopData = $missionVisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $missionVision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row p-4" style="background-color:#f2f2f2">
                <h3 class="text-center pt-5 pb-4">Vision</h3>
                <div class="cta-block">
                    <h3 style="text-align:justify;font-family: Century Gothic">
                        <?php echo $missionVision->vision; ?>

                    </h3>
                </div>
                <h3 class="text-center pt-5 pb-4">Mission</h3>
                <?php echo $missionVision->mission; ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/frontend/mission_vision.blade.php ENDPATH**/ ?>