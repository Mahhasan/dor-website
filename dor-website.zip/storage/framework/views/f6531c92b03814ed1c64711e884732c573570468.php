<?php $__env->startSection('content'); ?>
<section class="gallery bg-gray">
    <div class="container">
        <div class="row">
            <h4 style="text-align:justify;word-spacing:-2px; margin-bottom: 32px;">Daffodil International University follows the "Policy regarding the Qualification and Experiences of the Teacher Recruitment and Promotion of Private Universities that Recognizes Interdisciplinary Research" of the University Grants Commission (UGC) of Bangladesh for Teacher's recruitment and promotion.</h4>
            <div class="embed-responsive embed-responsive-16by9">
              <iframe class="embed-responsive-item" src="pdf/The_Policy_regarding_the_qualification_and_Experiences_of_the_Teacher_Recruitment_and_Promotion_of_Private_Universities1.pdf"></iframe>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dor-website\resources\views/promotion-policy.blade.php ENDPATH**/ ?>