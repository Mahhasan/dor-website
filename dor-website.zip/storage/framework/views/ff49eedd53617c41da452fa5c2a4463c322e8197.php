<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
        <div class="row">
            <div class="panel panel-primary">
                <div class="panel-heading">Rankings</div>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">Year</th>
                            <th scope="col">Name of University Rankings</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rankings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$ranking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($ranking->year); ?></th>
                                <td>
                                    <a href="<?php echo e($ranking->link); ?>" target="_blank"><?php echo e($ranking->title); ?></a>
                                </td>
                                <td>
                                    <a href="<?php echo e($ranking->link); ?>" target="_blank">
                                        <?php if($ranking->picture): ?>
                                            <img src="<?php echo e(asset('uploads/ranking/' . $ranking->picture)); ?>" style="display: block;margin-left: auto;margin-right: auto;max-width: 350px; max-height: 120px;">
                                        <?php else: ?>
                                            No Image Available
                                        <?php endif; ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
		</div>
    </div>
</section> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/frontend/ranking.blade.php ENDPATH**/ ?>