<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Cache;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use InvalidArgumentException;

class ProfileController extends Controller
{
    // Path to the JSON file
    private $jsonFilePath;

    public function __construct()
    {
        // Set the JSON file path for researcher data
        $this->jsonFilePath = public_path('rp-js/researchers.json');
    }

    public function index()
    {
        // Fetch the researchers data (from cache or file)
        $researcher = $this->getResearchers();

        if ($researcher instanceof \Illuminate\Http\RedirectResponse) {
            // If an error occurred, redirect back to the welcome page
            return $researcher;
        }

        // Pass the researchers data to the view
        return view('researchers', compact('researcher'));
    }

    public function show($departmentSF, $slug)
    {
        // Fetch the researchers data
        $researchers = $this->getResearchers();

        if ($researchers instanceof \Illuminate\Http\RedirectResponse) {
            // If an error occurred, redirect back to the welcome page
            return $researchers;
        }

        // Find the researcher by department and slug
        $researcher = $this->findResearcherByDepartmentAndSlug($researchers, $departmentSF, $slug);

        if (!$researcher) {
            return redirect()->route('researchers')->with('error', 'Researcher not found');
        }

        // Find similar researchers based on expertise
        $similarResearchers = $this->getSimilarResearchers($researchers, $researcher);

        return view('rprofile.show', compact('researcher', 'similarResearchers'));
    }

    private function getResearchers()
    {
        $cacheKey = 'researchers_data';

        return Cache::remember($cacheKey, 60 * 60, function () {
            try {
                if (!File::exists($this->jsonFilePath)) {
                    throw new FileNotFoundException('Researcher data file not found.');
                }

                $researchers = json_decode(File::get($this->jsonFilePath), true);

                // Validate the structure of the researchers data
                $this->validateResearcherData($researchers);

                return $researchers;
            } catch (FileNotFoundException $e) {
                return redirect()->route('researchers')->with('error', $e->getMessage());
            } catch (\Exception $e) {
                return redirect()->route('researchers')->with('error', 'An error occurred while fetching data.');
            }
        });
    }

    private function findResearcherByDepartmentAndSlug($researchers, $departmentSF, $slug)
    {
        return collect($researchers)->first(function ($r) use ($departmentSF, $slug) {
            return $r['departmentSF'] === $departmentSF && $r['slug'] === $slug;
        });
    }

    private function getSimilarResearchers($researchers, $researcher)
    {
        $similarResearchers = [];
        $researcherExpertise = $researcher['expertise'];

        foreach ($researchers as $r) {
            if ($r['id'] == $researcher['id']) continue;

            $commonExpertise = array_intersect($researcherExpertise, $r['expertise']);
            $matchCount = count($commonExpertise);

            if ($matchCount > 0) {
                $similarResearchers[] = [
                    'researcher' => $r,
                    'matchCount' => $matchCount,
                    'commonExpertise' => $commonExpertise, // Optionally pass common expertise for display
                ];
            }
        }

        // Sort researchers by match count in descending order and take top 5
        usort($similarResearchers, fn($a, $b) => $b['matchCount'] - $a['matchCount']);
        return array_slice($similarResearchers, 0, 5);
    }

    private function normalizeExpertise($expertise)
    {
        return strtolower(implode(' ', $expertise));
    }

    private function getQuotedExpertiseMatches($expertise)
    {
        preg_match_all('/"([^"]+)"/', implode(' ', $expertise), $matches);
        return $matches[1] ?? [];
    }

    private function getCommonExpertiseWords($researcherExpertise, $rExpertise)
    {
        return array_intersect(explode(' ', $researcherExpertise), explode(' ', $rExpertise));
    }

    private function getCommonQuotedExpertise($researcherMatches, $rExpertise)
    {
        $commonQuotedWords = [];
        foreach ($researcherMatches as $quotedPhrase) {
            if (stripos($rExpertise, $quotedPhrase) !== false) {
                $commonQuotedWords[] = $quotedPhrase;
            }
        }
        return $commonQuotedWords;
    }

    private function validateResearcherData($researchers)
    {
        foreach ($researchers as $researcher) {
            if (!isset($researcher['id'], $researcher['name'], $researcher['expertise'])) {
                throw new InvalidArgumentException('Invalid researcher data format.');
            }
        }
    }
}
