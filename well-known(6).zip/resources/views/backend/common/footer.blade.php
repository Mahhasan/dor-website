<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span><b> &copy; Copyright {{date('Y')}}. All Rights Reserved by Division of Research, 
          <a href="https://daffodilvarsity.edu.bd/">DIU</a></b></span>
        </div>
    </div>
</footer>