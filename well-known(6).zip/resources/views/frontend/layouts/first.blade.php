<section class="header-uper">
      <div class="container clearfix">
            <div class="logo">
                  <figure>
                        <a href="{{ url('/') }}">
                              <img src="images/diu.png" alt="">
                        </a>
                  </figure>
            </div>
            <div class="right-side">
                  <ul class="contact-info">
                        <li class="item">
                              <div class="">
                                    <i class="fa fa-facebook-round"></i>
                              </div>
                              <strong></strong>
                              <br>
                              <a href="#">
                                    <span></span>
                              </a>
                        </li>
                        <li class="item">
                              <div class="">
                                    <i class=""></i>
                              </div>
                              <strong></strong>
                              <br>
                              <span></span>
                        </li>
                  </ul>
                  <div class="link-btn">
                        <div class="md-form mt-0">
                          <input class="form-control" type="text" placeholder="Search" aria-label="Search">
                        </div>
                  </div>
            </div>
      </div>
</section>