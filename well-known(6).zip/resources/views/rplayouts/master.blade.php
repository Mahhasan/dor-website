<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Explore DIU Researchers Profiles - Find researchers by department, expertise, and more.">
    <meta name="keywords" content="DIU, researchers, profiles, university, expertise, faculty">
    <meta name="author" content="Daffodil International University">

    <!-- Open Graph meta tags for social media sharing -->
    <meta property="og:title" content="DIU Researchers Profile">
    <meta property="og:description" content="Explore DIU Researchers Profiles - Find researchers by department, expertise, and more.">
    <meta property="og:image" content="{{ asset('rp-img/diulogo.png') }}">
    <meta property="og:url" content="{{ url('/') }}">
    <title>DIU Researchers Profile</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('rp-img/favicon.png') }}" />
    <!-- Bootstrap CSS -->
    <link href="{{ asset('rp-css/bootstrap.min.css') }}" rel="stylesheet" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
      integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Link to Maven Pro font for the body text -->
    <link href="https://fonts.googleapis.com/css2?family=Maven+Pro:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- Link to Acme font for the navbar brand -->
    <link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('rp-css/style.css') }}" />
  </head>
  <body>

  <!-- Top Menu -->
  <div class="top-menu bg-primary d-none d-lg-block">
  <div class="container-fluid py-1">
    <div class="d-flex justify-content-between align-items-center">
      <!-- Left Section: DIU link -->
      <div class="d-flex justify-content-between" style="font-size: 0.9rem;">
        <a class="nav-link active text-white mx-2 fw-medium" href="https://daffodilvarsity.edu.bd/">
          <small><a class="text-decoration-none text-light" href="mailto:info@daffodilvarsity.edu.bd"><i class="fa fa-envelope" aria-hidden="true"></i> info@daffodilvarsity.edu.bd</a></small>
        </a>
        <a class="nav-link active text-white mx-2 fw-medium" href="https://daffodilvarsity.edu.bd/">
        <small><a class="text-decoration-none text-light" href="tel:+8809617901233"><i class="fa fa-envelope" aria-hidden="true"></i> +8809617901233</a></small>
        </a>
      </div>

      <!-- Right Section: Links for DoR, Journals, DIUJST, etc. -->
      <div class="d-flex justify-content-between"  style="text-transform: uppercase; font-size: 0.8rem;">
        <a class="nav-link active text-white mx-2 fw-medium" href="https://daffodilvarsity.edu.bd/"><small>DIU</small></a>
        <a class="nav-link active text-white mx-2 fw-medium" href="http://research.daffodilvarsity.edu.bd/"><small>DoR</small></a>
        <a class="nav-link active text-white mx-2 fw-medium" href="https://journals.daffodilvarsity.edu.bd/"><small>Journals</small></a>
        <a class="nav-link active text-white mx-2 fw-medium" href="https://diujst.daffodilvarsity.edu.bd/"><small>DIUJST</small></a>
        <a class="nav-link active text-white mx-2 fw-medium" href="https://diujahs.daffodilvarsity.edu.bd/"><small>DIUJAHS</small></a>
        <a class="nav-link active text-white mx-2 fw-medium" href="https://diujbe.daffodilvarsity.edu.bd/"><small>DIUJBE</small></a>
        <a class="nav-link active text-white mx-2 fw-medium" href="https://diujhss.daffodilvarsity.edu.bd/"><small>DIUJHSS</small></a>
      </div>
    </div>
  </div>
</div>


<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light shadow mb-5 py-3">
  <div class="container-fluid">
    <div class="container d-flex justify-content-between align-items-center">
      <!-- Navbar Brand (Left side) -->
      <a class="navbar-brand fw-medium text-primary d-none d-md-block fw-bold" href="/researchers">
        DIU RESEARCHERS PROFILE
      </a>

      <!-- Logo (Right side) -->
      <a href="javascript:void(0)" style="cursor: pointer;">
        <img src="https://daffodilvarsity.edu.bd/template/images/diulogoside.png" width="180px" alt="Daffodil International University">
      </a>
    </div>
  </div>
</nav>
    <div class="container">
      @yield('content') 
    </div>

    <div class="row copyright-section d-none">
      <div class="col-md-12 text-center pb-3">
        <b>Copyright © 2024 Daffodil International University. All Rights Reserved.</b>
      </div>
    </div>

    <!-- Bootstrap JS and Dependencies -->
    <script src="{{ asset('rp-js/bootstrap.bundle.min.js') }}"></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/js/all.min.js"
      integrity="sha512-6sSYJqDreZRZGkJ3b+YfdhB3MzmuP9R7X1QZ6g5aIXhRvR1Y/N/P47jmnkENm7YL3oqsmI6AK+V6AD99uWDnIw=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Toastr Notifications -->
    @if(Session::has('success'))
    <script>
        $(function() {
            toastr.success("{{ Session::get('success') }}");
        });
    </script>
    @elseif(Session::has('fail'))
    <script>
        $(function() {
            toastr.error("{{ Session::get('fail') }}");
        });
    </script>
    @elseif(Session::has('warning'))
    <script>
        $(function() {
            toastr.warning("{{ Session::get('warning') }}");
        });
    </script>
    @elseif(Session::has('error'))
    <script>
        $(function() {
            toastr.error("{{ Session::get('error') }}");
        });
    </script>
    @endif
    <script>
        document.addEventListener('keydown', function(e) {
            if (e.key === 'F12' || 
                (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C')) || 
                (e.ctrlKey && e.key === 'u')) {
                e.preventDefault();
            }
        });
    </script>
  </body>
</html>
