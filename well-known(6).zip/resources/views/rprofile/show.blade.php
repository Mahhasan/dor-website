@extends('rplayouts.master')

@section('head')
    <!-- SEO Meta Tags -->
    <meta name="description" content="{{ $researcher['name'] }} is a researcher specializing in {{ implode(', ', $researcher['expertise']) }}. Explore their profile, research, and academic work.">
    <meta name="keywords" content="researcher, {{ $researcher['name'] }}, academic profile, research expertise, {{ implode(', ', $researcher['expertise']) }}">
    <meta name="author" content="{{ $researcher['name'] }}">

    <!-- Open Graph Meta Tags -->
    <meta property="og:type" content="profile">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:title" content="{{ $researcher['name'] }} - Researcher Profile">
    <meta property="og:description" content="{{ $researcher['name'] }} specializes in research in areas like {{ implode(', ', $researcher['expertise']) }}.">
    <meta property="og:image" content="{{ url(asset($researcher['image'])) }}">
    
    <!-- Twitter Card Meta Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="{{ $researcher['name'] }} - Researcher Profile">
    <meta name="twitter:description" content="{{ $researcher['name'] }} is a leading researcher in {{ implode(', ', $researcher['expertise']) }}.">
    <meta name="twitter:image" content="{{ url(asset($researcher['image'])) }}">
    
    <title>{{ $researcher['name'] }} - Researcher Profile</title>
    <link rel="icon" href="{{ asset('rp-img/favicon.png') }}">
@endsection

@section('content')
    <!-- Profile Content -->
    <div class="card mx-auto mb-4" style="max-width: 100%;">
        <div class="card-body">
            <!-- Image Left-Aligned -->
            <img src="{{ asset($researcher['image']) }}" alt="{{ $researcher['name'] }}" class="profile-image img-fluid float-start me-4" style="max-width: 120px;">
            
            <h3 class="card-title mt-2 mb-0 text-primary">{{ $researcher['name'] }}</h3>
            <small class="card-text">{{ $researcher['designation'] }}</small>
            <p class="card-text mt-1">{{ $researcher['department'] }}, {{ $researcher['faculty'] }}</p>

            <div class="d-flex flex-wrap justify-content-start">
                @if($researcher['diuPortfolio'])
                    <a href="{{ $researcher['diuPortfolio'] }}" class="btn btn-sm btn-primary m-1 text-nowrap" target="_blank">
                        <i class="fa-solid fa-globe"></i> DIU Portfolio
                    </a>
                @endif
                @if($researcher['orcidProfile'])
                    <a href="{{ $researcher['orcidProfile'] }}" class="btn btn-sm btn-primary m-1 text-nowrap" target="_blank">
                        <i class="fa-brands fa-orcid"></i> ORCID Profile
                    </a>
                @endif
                @if($researcher['scopusProfile'])
                    <a href="{{ $researcher['scopusProfile'] }}" class="btn btn-sm btn-primary m-1 text-nowrap" target="_blank">
                        <i class="fa-solid fa-globe"></i> Scopus Profile
                    </a>
                @endif
                @if($researcher['googleSite'])
                    <a href="{{ $researcher['googleSite'] }}" class="btn btn-sm btn-primary m-1 text-nowrap" target="_blank">
                        <i class="fa-brands fa-google"></i> Google Scholar
                    </a>
                @endif
                @if($researcher['wosProfile'])
                    <a href="{{ $researcher['wosProfile'] }}" class="btn btn-sm btn-primary m-1 text-nowrap" target="_blank">
                        <i class="fa-solid fa-globe"></i> Web of Science
                    </a>
                @endif
            </div>
            <hr>
            <h5 class="text-primary">Short Biography</h5>
            <hr style="width: 4%; height: 3px; color: #034ea2; background-color: #034ea2 !important; opacity: 1; margin-top: 4px;"> 
            <p>{{ $researcher['bio'] }}</p>

            <h5 class="text-primary">Expertise Areas</h5>
            <hr style="width: 4%; height: 3px; color: #034ea2; background-color: #034ea2 !important; opacity: 1; margin-top: 4px;">
            <div class="row">
                <!-- First Half of Expertise Areas -->
                <div class="col-sm-6">
                    <ul class="expertise-list">
                        @foreach(array_slice($researcher['expertise'], 0, ceil(count($researcher['expertise']) / 2)) as $expertise)
                            <li>
                                <a style="text-decoration: none;" class="text-primary" href="https://www.google.com/search?q={{ urlencode('What is ' . $expertise . ' in terms of research?') }}" target="_blank" title="Click to learn more about {{ $expertise }}">
                                    {{ $expertise }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>

                <!-- Second Half of Expertise Areas -->
                <div class="col-sm-6">
                    <ul class="expertise-list">
                        @foreach(array_slice($researcher['expertise'], ceil(count($researcher['expertise']) / 2)) as $expertise)
                            <li>
                                <a style="text-decoration: none;" class="text-primary" href="https://www.google.com/search?q={{ urlencode('What is ' . $expertise . ' in terms of research?') }}" target="_blank" title="Click to learn more about {{ $expertise }}">
                                    {{ $expertise }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
            <hr>
            <!-- Suggested Researchers-->
            @if($similarResearchers && count($similarResearchers) > 0)
                <div class="py-3">
                    <h5 class="text-primary">Researchers from similar research field</h5>
                    <hr style="width: 4%; height: 3px; color: #034ea2; background-color: #034ea2 !important; opacity: 1; margin-top: 4px;">
                    <div class="suggested-researchers">
                        @foreach($similarResearchers as $similar)
                            <div class="suggested-researcher">
                                <!-- Card for each researcher -->
                                <div class="suggested-card">
                                    <!-- Image -->
                                    <img 
                                        src="{{ asset($similar['researcher']['image'] ?? 'img/profile-default.svg') }}" 
                                        class="suggested-card-img-top mx-auto" 
                                        alt="{{ $similar['researcher']['name'] }}">

                                    <div class="suggested-card-body">
                                        <h5 class="suggested-card-title text-center">{{ $similar['researcher']['name'] }}</h5>
                                        <a href="{{ url('researchers/' . $similar['researcher']['departmentSF'] . '/' . $similar['researcher']['slug']) }}" class="btn btn-sm btn-primary">
                                            <i class="fa fa-eye" aria-hidden="true"></i> View Profile
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endif

            <!-- Social Share Buttons and Back Button -->
            <div class="mt-3 d-flex flex-wrap justify-content-between align-items-center">
                <!-- Share Buttons (Left Side) -->
                <div class="d-flex flex-wrap justify-content-center justify-content-sm-start">
                    <!-- Facebook -->
                    <a href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode(url()->current()) }}" target="_blank" title="Share on Facebook" class="me-0">
                        <img src="{{asset('rp-img/fb.jpg')}}" alt="Share Button Facebook" width="75%" height="auto" class="d-block mb-3">
                    </a>

                    <!-- X (formerly Twitter) -->
                    <a href="https://twitter.com/intent/tweet?url={{ urlencode(url()->current()) }}" target="_blank" title="Share on X" class="me-0">
                        <img src="{{asset('rp-img/x.png')}}" alt="Share Button X" width="75%" height="auto" class="d-block mb-3">
                    </a>

                    <!-- WhatsApp -->
                    <a href="https://wa.me/?text={{ urlencode(url()->current()) }}" target="_blank" title="Share on WhatsApp" class="me-0">
                        <img src="{{asset('rp-img/wp.jpg')}}" alt="Share Button WhatsApp" width="75%" height="auto" class="d-block mb-3">
                    </a>

                    <!-- LinkedIn -->
                    <a href="https://www.linkedin.com/sharing/share-offsite/?url={{ urlencode(url()->current()) }}" target="_blank" title="Share on LinkedIn" class="me-0">
                        <img src="{{asset('rp-img/ln.png')}}" alt="Share Button LinkedIn" width="75%" height="auto" class="d-block mb-3">
                    </a>
                </div>

                <!-- Back to Homepage Button (Right Side) -->
                <div>
                    <a href="{{ route('researchers') }}" class="btn btn-sm btn-secondary mb-3">
                        <i class="fa fa-arrow-left" aria-hidden="true"></i> Back to Homepage
                    </a>
                </div>
            </div>
        </div>
    </div>
@endsection