
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($resource)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Add New Resource">Add New Resource</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($resource) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <?php if(isset($resource)): ?>
            <h6>Edit <span class="text-success font-weight-bold"><?php echo e($resource->topic); ?>'s</span> Record</h6>
            <form method="POST" action="<?php echo e(route('resources.update', $resource->id)); ?>" enctype="multipart/form-data">
                <?php echo method_field('PATCH'); ?>
            <?php else: ?>
            <h6>Add New Resource</h6>
            <form method="POST" action="<?php echo e(route('resources.store')); ?>" enctype="multipart/form-data">
            <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container mb-4">
                        <input type="text" class="input" id="topic" name="topic" value="<?php echo e(old('topic', isset($resource) ? $resource->topic : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="topic" class="placeholder">Topic <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container mb-4">
                        <input type="file" class="input border-0 pt-2" id="document" name="document" <?php echo e(isset($resource) ? '' : 'required'); ?> accept="application/pdf">
                        <?php if(isset($resource) && $resource->document): ?>
                            <div class=" mt-3 float-right">
                                <?php if(pathinfo($resource->document, PATHINFO_EXTENSION) == 'pdf'): ?>
                                    <a href="<?php echo e(asset('uploads/resource/' . $resource->document)); ?>" target="_blank"><iframe src="<?php echo e(asset('uploads/resource/' . $resource->document)); ?>" style="width: 100%; height: auto;"></iframe></a>
                                <?php else: ?>
                                    <a href="<?php echo e(asset('uploads/resource/' . $resource->document)); ?>" target="_blank"><img src="<?php echo e(asset('uploads/resource/' . $resource->document)); ?>" alt="<?php echo e($resource->topic); ?>" width="100"></a>
                                <?php endif; ?>
                                <!-- <a href="<?php echo e(asset('uploads/resource/' . $resource->document)); ?>" target="_blank"><?php echo e($resource->document); ?></a> -->
                            </div>
                        <?php endif; ?>    
                        <div class="cut"></div>
                        <label for="document" class="placeholder">Rrsource File <small class="font-italic">(Image or pdf)</small> <span class="text-danger">*</span></label>            
                    </div>
                </div>
                <?php if(isset($resource)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('resources.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="row d-block">
        <div class="mx-auto pt-5 pb-5">
            <h5 class="text-center mb-5">Resource Records</h5>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Topic</th>
                            <th>Resource File</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($resources)): ?>
                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($resource->topic); ?></td>
                                    <td>
                                        <?php if(pathinfo($resource->document, PATHINFO_EXTENSION) == 'pdf'): ?>
                                            <iframe src="<?php echo e(asset('uploads/resource/' . $resource->document)); ?>" style="width: 100%; height: auto;"></iframe>
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('uploads/resource/' . $resource->document)); ?>" alt="<?php echo e($resource->topic); ?>" width="100">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(asset('uploads/resource/' . $resource->document)); ?>" class="btn-sm" target="_blank" title="View Document"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                        <a href="<?php echo e(route('resources.edit', $resource->id)); ?>" class="btn btn-sm text-primary" title="Edit <?php echo e($resource->topic); ?>'s information"><i class="fas fa-edit fa-sm"></i></a>
                                        <form action="<?php echo e(route('resources.destroy', $resource->id)); ?>" method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm text-danger" onclick="return confirm('Are you sure you want to delete this record?')" title="Delete <?php echo e($resource->topic); ?>'s information"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/backend/resources.blade.php ENDPATH**/ ?>