
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($photo)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Upload New Photo">Upload New Photo</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($photo) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <?php if(isset($photo)): ?>
            <h6>Edit <span class="text-success font-weight-bold"><?php echo e($photo->title); ?> - <?php echo e($photo->year); ?></span> Record</h6>
            <form method="POST" action="<?php echo e(route('photos.update', $photo->id)); ?>" enctype="multipart/form-data">
            <?php echo method_field('PATCH'); ?>
            <?php else: ?>
            <h6>Upload New Photo</h6>
            <form method="POST" action="<?php echo e(route('photos.store')); ?>" enctype="multipart/form-data">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container col-sm-12 mb-4">
                        <input type="text" class="input" id="title" name="title" value="<?php echo e(old('title', isset($photo) ? $photo->title : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="title" class="placeholder">Title <span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-md-5 mb-4">
                        <select class="input" id="year" name="year" required>
                            <option value="">Select Year</option>
                            <?php
                                $currentYear = date('Y');
                            ?>
                            
                            <?php for($i = $currentYear; $i >= ($currentYear - 40); $i--): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e(old('year', isset($photo) && $photo->year == $i ? 'selected' : '')); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                        <div class="cut"></div>
                        <label for="year" class="placeholder">Year <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-md-7 mb-4">
                        <div class="additional-links">
                            <?php if(isset($photo) && $photo->links): ?>
                                <?php $__currentLoopData = json_decode($photo->links, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row input-container mb-5">
                                        <div class="col-9 col-lg-10">
                                            <input type="url" class="input" id="link" name="links[]" value="<?php echo e(old('links.' . $index, $link)); ?>" placeholder=" "/>
                                            <div class="cut"></div>
                                            <label for="link" class="placeholder">Image Link <?php echo e($index + 1); ?></label>
                                            <iframe class="mt-3" src="<?php echo e($link); ?>" frameborder="0" height="auto" width="100%"></iframe>
                                        </div>
                                        <button type="button" class="col-3 col-lg-2 btn btn-outline-danger remove-link">Remove</button>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="btn btn-outline-info" id="add-link">Insert Additional Image Link  (if any)</button>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-12 mb-4">
                        <input type="file" class="input border-0 pt-2" id="pictures" name="pictures[]" accept="image/*" multiple>
                        <?php if(isset($photo) && $photo->pictures): ?>
                            <div class="row existing-pictures float-right mt-3 ml-1 mr-1">
                                <?php $__currentLoopData = json_decode($photo->pictures, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="existing-picture mr-2 mb-2">
                                        <input type="checkbox" name="deleted_pictures[]" value="<?php echo e($picture); ?>">
                                        <img src="<?php echo e(asset('uploads/photos/' . $picture)); ?>" alt="<?php echo e($photo->title); ?> Image" height="100px" width="150">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <p><small class="font-italic">(If you want to remove an image then select it)</small></p>
                        <?php endif; ?>   
                        <div class="cut"></div>
                        <label for="pictures" class="placeholder">Gallery Image<small class="font-italic"> (size: 1000 x 665 px, Max 150 KB, Max 20 image at a time)</small></label>
                    </div>
                </div>
                <?php if(isset($photo)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('photos.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="mx-auto mb-5">
        <h5 class="text-center pt-5">Photo Gallery</h5>
    </div>


    <div class="row d-block">
        <div class="mx-auto pb-5">
            <div class="table-responsive">
                <table class="table table-striped" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Photos</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <!-- <td><?php echo e(++$key); ?></td> -->
                                    <div class="text-right">
                                        <a href="<?php echo e(route('photos.edit', $photo->id)); ?>" class="btn text-primary"><i class="fas fa-edit fa-sm"></i></a>
                                        <form action="<?php echo e(route('photos.destroy', $photo->id)); ?>" method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn text-danger" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                                        </form>
                                    </div>
                                    <div class="p-1">
                                        <p><?php echo e($photo->title); ?> - <?php echo e($photo->year); ?></p>
                                    </div>
                                
                                    <?php if($photo->pictures): ?>
                                        <div class="existing-pictures">
                                            <?php $__currentLoopData = json_decode($photo->pictures, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <img class="mb-2 p-2" src="<?php echo e(asset('uploads/photos/' . $picture)); ?>" alt="<?php echo e($photo->title); ?> Image" height="180" width="260">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php else: ?>
                                        No Images Available
                                    <?php endif; ?>
                                    <?php if($photo->links): ?>
                                        <div class="existing-links">
                                            <?php $__currentLoopData = json_decode($photo->links, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <iframe class="p-2" src="<?php echo e($link); ?>" frameborder="0" height="180" width="260"></iframe>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php else: ?>
                                        No Images Available
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        // Add Link button click event
        $('#add-link').click(function () {
            var linkField = `
                <div class="row input-container mb-4">
                    <div class="col-8 col-lg-10">
                        <input type="url" class="input" name="links[]" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="link" class="placeholder">Image Link</label>
                    </div>
                    <button type="button" class="col-4 col-lg-2 btn btn-outline-danger remove-link">Remove</button>
                </div>
            `;
            $('.additional-links').append(linkField);
        });

        // Remove Link button click event
        $('.additional-links').on('click', '.remove-link', function () {
            $(this).closest('.input-container').remove();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/backend/photos.blade.php ENDPATH**/ ?>