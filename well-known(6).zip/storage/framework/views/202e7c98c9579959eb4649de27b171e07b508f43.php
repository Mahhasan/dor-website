

<?php $__env->startSection('head'); ?>
    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo e($researcher['name']); ?> is a researcher specializing in <?php echo e(implode(', ', $researcher['expertise'])); ?>. Explore their profile, research, and academic work.">
    <meta name="keywords" content="researcher, <?php echo e($researcher['name']); ?>, academic profile, research expertise, <?php echo e(implode(', ', $researcher['expertise'])); ?>">
    <meta name="author" content="<?php echo e($researcher['name']); ?>">

    <!-- Open Graph Meta Tags -->
    <meta property="og:type" content="profile">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:title" content="<?php echo e($researcher['name']); ?> - Researcher Profile">
    <meta property="og:description" content="<?php echo e($researcher['name']); ?> specializes in research in areas like <?php echo e(implode(', ', $researcher['expertise'])); ?>.">
    <meta property="og:image" content="<?php echo e(url(asset($researcher['image']))); ?>">
    
    <!-- Twitter Card Meta Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($researcher['name']); ?> - Researcher Profile">
    <meta name="twitter:description" content="<?php echo e($researcher['name']); ?> is a leading researcher in <?php echo e(implode(', ', $researcher['expertise'])); ?>.">
    <meta name="twitter:image" content="<?php echo e(url(asset($researcher['image']))); ?>">
    
    <title><?php echo e($researcher['name']); ?> - Researcher Profile</title>
    <link rel="icon" href="<?php echo e(asset('rp-img/favicon.png')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Profile Content -->
    <div class="card mx-auto mb-4" style="max-width: 100%;">
        <div class="card-body">
            <!-- Image Left-Aligned -->
            <img src="<?php echo e(asset($researcher['image'])); ?>" alt="<?php echo e($researcher['name']); ?>" class="profile-image img-fluid float-start me-4" style="max-width: 120px;">
            
            <h3 class="card-title mt-2 mb-0 text-primary"><?php echo e($researcher['name']); ?></h3>
            <small class="card-text"><?php echo e($researcher['designation']); ?></small>
            <p class="card-text mt-1"><?php echo e($researcher['department']); ?>, <?php echo e($researcher['faculty']); ?></p>

            <div class="d-flex flex-wrap justify-content-start">
                <?php if($researcher['diuPortfolio']): ?>
                    <a href="<?php echo e($researcher['diuPortfolio']); ?>" class="btn btn-sm btn-primary m-1 text-nowrap" target="_blank">
                        <i class="fa-solid fa-globe"></i> DIU Portfolio
                    </a>
                <?php endif; ?>
                <?php if($researcher['orcidProfile']): ?>
                    <a href="<?php echo e($researcher['orcidProfile']); ?>" class="btn btn-sm btn-primary m-1 text-nowrap" target="_blank">
                        <i class="fa-brands fa-orcid"></i> ORCID Profile
                    </a>
                <?php endif; ?>
                <?php if($researcher['scopusProfile']): ?>
                    <a href="<?php echo e($researcher['scopusProfile']); ?>" class="btn btn-sm btn-primary m-1 text-nowrap" target="_blank">
                        <i class="fa-solid fa-globe"></i> Scopus Profile
                    </a>
                <?php endif; ?>
                <?php if($researcher['googleSite']): ?>
                    <a href="<?php echo e($researcher['googleSite']); ?>" class="btn btn-sm btn-primary m-1 text-nowrap" target="_blank">
                        <i class="fa-brands fa-google"></i> Google Scholar
                    </a>
                <?php endif; ?>
                <?php if($researcher['wosProfile']): ?>
                    <a href="<?php echo e($researcher['wosProfile']); ?>" class="btn btn-sm btn-primary m-1 text-nowrap" target="_blank">
                        <i class="fa-solid fa-globe"></i> Web of Science
                    </a>
                <?php endif; ?>
            </div>
            <hr>
            <h5 class="text-primary">Short Biography</h5>
            <hr style="width: 4%; height: 3px; color: #034ea2; background-color: #034ea2 !important; opacity: 1; margin-top: 4px;"> 
            <p><?php echo e($researcher['bio']); ?></p>

            <h5 class="text-primary">Expertise Areas</h5>
            <hr style="width: 4%; height: 3px; color: #034ea2; background-color: #034ea2 !important; opacity: 1; margin-top: 4px;">
            <div class="row">
                <!-- First Half of Expertise Areas -->
                <div class="col-sm-6">
                    <ul class="expertise-list">
                        <?php $__currentLoopData = array_slice($researcher['expertise'], 0, ceil(count($researcher['expertise']) / 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expertise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a style="text-decoration: none;" class="text-primary" href="https://www.google.com/search?q=<?php echo e(urlencode('What is ' . $expertise . ' in terms of research?')); ?>" target="_blank" title="Click to learn more about <?php echo e($expertise); ?>">
                                    <?php echo e($expertise); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <!-- Second Half of Expertise Areas -->
                <div class="col-sm-6">
                    <ul class="expertise-list">
                        <?php $__currentLoopData = array_slice($researcher['expertise'], ceil(count($researcher['expertise']) / 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expertise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a style="text-decoration: none;" class="text-primary" href="https://www.google.com/search?q=<?php echo e(urlencode('What is ' . $expertise . ' in terms of research?')); ?>" target="_blank" title="Click to learn more about <?php echo e($expertise); ?>">
                                    <?php echo e($expertise); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <hr>
            <!-- Suggested Researchers-->
            <?php if($similarResearchers && count($similarResearchers) > 0): ?>
                <div class="py-3">
                    <h5 class="text-primary">Researchers from similar research field</h5>
                    <hr style="width: 4%; height: 3px; color: #034ea2; background-color: #034ea2 !important; opacity: 1; margin-top: 4px;">
                    <div class="suggested-researchers">
                        <?php $__currentLoopData = $similarResearchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="suggested-researcher">
                                <!-- Card for each researcher -->
                                <div class="suggested-card">
                                    <!-- Image -->
                                    <img 
                                        src="<?php echo e(asset($similar['researcher']['image'] ?? 'img/profile-default.svg')); ?>" 
                                        class="suggested-card-img-top mx-auto" 
                                        alt="<?php echo e($similar['researcher']['name']); ?>">

                                    <div class="suggested-card-body">
                                        <h5 class="suggested-card-title text-center"><?php echo e($similar['researcher']['name']); ?></h5>
                                        <a href="<?php echo e(url('researchers/' . $similar['researcher']['departmentSF'] . '/' . $similar['researcher']['slug'])); ?>" class="btn btn-sm btn-primary">
                                            <i class="fa fa-eye" aria-hidden="true"></i> View Profile
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Social Share Buttons and Back Button -->
            <div class="mt-3 d-flex flex-wrap justify-content-between align-items-center">
                <!-- Share Buttons (Left Side) -->
                <div class="d-flex flex-wrap justify-content-center justify-content-sm-start">
                    <!-- Facebook -->
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url()->current())); ?>" target="_blank" title="Share on Facebook" class="me-0">
                        <img src="<?php echo e(asset('rp-img/fb.jpg')); ?>" alt="Share Button Facebook" width="75%" height="auto" class="d-block mb-3">
                    </a>

                    <!-- X (formerly Twitter) -->
                    <a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(url()->current())); ?>" target="_blank" title="Share on X" class="me-0">
                        <img src="<?php echo e(asset('rp-img/x.png')); ?>" alt="Share Button X" width="75%" height="auto" class="d-block mb-3">
                    </a>

                    <!-- WhatsApp -->
                    <a href="https://wa.me/?text=<?php echo e(urlencode(url()->current())); ?>" target="_blank" title="Share on WhatsApp" class="me-0">
                        <img src="<?php echo e(asset('rp-img/wp.jpg')); ?>" alt="Share Button WhatsApp" width="75%" height="auto" class="d-block mb-3">
                    </a>

                    <!-- LinkedIn -->
                    <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e(urlencode(url()->current())); ?>" target="_blank" title="Share on LinkedIn" class="me-0">
                        <img src="<?php echo e(asset('rp-img/ln.png')); ?>" alt="Share Button LinkedIn" width="75%" height="auto" class="d-block mb-3">
                    </a>
                </div>

                <!-- Back to Homepage Button (Right Side) -->
                <div>
                    <a href="<?php echo e(route('researchers')); ?>" class="btn btn-sm btn-secondary mb-3">
                        <i class="fa fa-arrow-left" aria-hidden="true"></i> Back to Homepage
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('rplayouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/rprofile/show.blade.php ENDPATH**/ ?>