
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($researchUpdate)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Add Research Update">Add Research Update</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($researchUpdate) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <?php if(isset($researchUpdate)): ?>
            <h6>Edit <span class="text-success font-weight-bold"><?php echo e($researchUpdate->volume); ?></span></h6>
            <form method="POST" action="<?php echo e(route('research.update.update', $researchUpdate->id)); ?>" enctype="multipart/form-data">
                <?php echo method_field('PATCH'); ?>
            <?php else: ?>
            <h6>Add Research Update</h6>
            <form method="POST" action="<?php echo e(route('research.update.store')); ?>" enctype="multipart/form-data">
            <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container mb-4">
                        <input type="text" class="input" id="volume" name="volume" value="<?php echo e(old('volume', isset($researchUpdate) ? $researchUpdate->volume : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="volume" class="placeholder">Volume <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container mb-4">
                        <input type="file" class="input border-0 pt-2" id="file" name="file" <?php echo e(isset($researchUpdate) ? '' : 'required'); ?> placeholder=" " accept="application/pdf">
                            <div class=" mt-3 float-right">
                                <?php if(isset($researchUpdate) && $researchUpdate->file): ?>
                                    <!-- <a href="<?php echo e(asset('uploads/research_update/' . $researchUpdate->file)); ?>" target="_blank"><?php echo e($researchUpdate->file); ?></a> -->
                                    <a href="<?php echo e(asset('uploads/research_update/' . $researchUpdate->file)); ?>" target="_blank"><iframe src="<?php echo e(asset('uploads/research_update/' . $researchUpdate->file)); ?>" style="width: 100%; height: auto;"></iframe>view</a>
                                <?php endif; ?>
                            </div>
                        <div class="cut"></div>
                        <label for="file" class="placeholder">File <small class="font-italic">(pdf only, max size: 10mb)</small> <span class="text-danger">*</span></label>
                    </div>
                </div>
                <?php if(isset($researchUpdate)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('research.update.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="mx-auto mt-5 mb-5">
        <h5 class="text-center pt-5">Research Update Records</h5>
        <hr>
    </div>

    <div class="row mb-5">
        <?php $__currentLoopData = $researchUpdates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $researchUpdate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 mb-4 mx-auto">
                <div class="card border-0">
                    <?php if($researchUpdate->file): ?>
                        <div class="text-center">
                            <iframe src="<?php echo e(asset('uploads/research_update/' . $researchUpdate->file)); ?>" width="100%" height="400px"></iframe>
                        </div>
                    <?php else: ?>
                            No File Available
                    <?php endif; ?>
                    <div class="card-body">
                        <a href="<?php echo e(asset('uploads/research_update/' . $researchUpdate->file)); ?>" class="" target="_blank" title="View file"><?php echo e($researchUpdate->volume); ?></a>
                        <form action="<?php echo e(route('research.update.destroy', $researchUpdate->id)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="float-right btn btn-sm text-danger" onclick="return confirm('Are you sure you want to delete this record?')" title="Delete <?php echo e($researchUpdate->volume); ?>'s information"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                        </form>
                        <a href="<?php echo e(route('research.update.edit', $researchUpdate->id)); ?>" class="float-right btn btn-sm text-primary" title="Edit <?php echo e($researchUpdate->volume); ?>'s file"><i class="fas fa-edit fa-sm"></i></a>
                        <a href="<?php echo e(asset('uploads/research_update/' . $researchUpdate->file)); ?>" class="float-right btn btn-sm text-primary" target="_blank" title="View file"><i class="fa fa-eye" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/backend/research_update.blade.php ENDPATH**/ ?>