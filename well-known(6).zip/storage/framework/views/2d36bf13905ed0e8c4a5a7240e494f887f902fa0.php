
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($event)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Add New Event">Add New Event</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($event) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <?php if(isset($event)): ?>
            <h6>Edit This Event</h6>
            <form method="POST" action="<?php echo e(route('events.update', $event->id)); ?>" enctype="multipart/form-data">
                <?php echo method_field('PATCH'); ?>
                <?php else: ?>
                <h6>Add New Event</h6>
            <form method="POST" action="<?php echo e(route('events.store')); ?>" enctype="multipart/form-data">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container col-md-8 mb-4">
                        <input type="text" class="input" id="title" name="title" value="<?php echo e(old('title', isset($event) ? $event->title : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="title" class="placeholder">Event Title <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-md-4 mb-4">
                        <select class="input" id="year" name="year" required>
                            <option value="">Select Year</option>
                            <?php
                                $currentYear = date('Y');
                            ?>
                            
                            <?php for($i = $currentYear; $i >= ($currentYear - 40); $i--): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e(old('year', isset($event) && $event->year == $i ? 'selected' : '')); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                        <div class="cut"></div>
                        <label for="year" class="placeholder">Year <span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-sm-12 mb-4">
                    <textarea class="input" id="file-picker" name="event_details" value="<?php echo e(old('event_details', isset($event) ? $event->event_details : '')); ?>" required placeholder=" "><?php echo e(old('event_details', isset($event) ? $event->event_details : '')); ?></textarea>
                    <div class="cut"></div>
                    <label for="event_details" class="placeholder">Event Details <span class="text-danger">*</span></label>    
                </div>
                </div>
                <?php if(isset($event)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('events.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="row d-block">
        <div class="mx-auto pt-5 pb-5">
            <h5 class="text-center mb-5">Events</h5>
            <div class="table-responsive">
                <table class="table table-bordered table-striped" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Events</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="text-right">
                                        <a href="<?php echo e(route('events.edit', $event->id)); ?>" class="btn btn-sm text-primary"><i class="fas fa-edit fa-sm"></i></a>
                                        <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm text-danger" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                                        </form>
                                    </div>
                                    <p class="mt-2"><?php echo e(++$key); ?>. <?php echo e($event->title); ?> - <?php echo e($event->year); ?></p>
                                    <div class="content-justify mt-5">
                                        <?php echo $event->event_details; ?>

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/backend/event.blade.php ENDPATH**/ ?>