<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span><b> &copy; Copyright <?php echo e(date('Y')); ?>. All Rights Reserved by Division of Research, 
          <a href="https://daffodilvarsity.edu.bd/">DIU</a></b></span>
        </div>
    </div>
</footer><?php /**PATH /home/researchdaffodil/public_html/resources/views/backend/common/footer.blade.php ENDPATH**/ ?>