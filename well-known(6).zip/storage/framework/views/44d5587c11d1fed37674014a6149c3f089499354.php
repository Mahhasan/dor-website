
<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
        <div class="row">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <!--<th scope="col">Sl. No</th>-->
                        <th scope="col">Events</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!--<th scope="row">1</th>-->
                            <td><a href="<?php echo e(route('event-details', $event->id)); ?>" target="_blank"><?php echo e($event->title); ?> - <?php echo e($event->year); ?></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/frontend/event.blade.php ENDPATH**/ ?>