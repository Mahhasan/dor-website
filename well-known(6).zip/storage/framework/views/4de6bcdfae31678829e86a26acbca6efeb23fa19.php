
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($ranking)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Add New Ranking">Add New Ranking</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($ranking) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <?php if(isset($ranking)): ?>
            <h6>Edit <span class="text-success font-weight-bold"><?php echo e($ranking->title); ?> - <?php echo e($ranking->year); ?></span></h6>
            <form method="POST" action="<?php echo e(route('rankings.update', $ranking->id)); ?>" enctype="multipart/form-data">
                <?php echo method_field('PATCH'); ?>
                <?php else: ?>
                <h6>Add New Ranking</h6>
            <form method="POST" action="<?php echo e(route('rankings.store')); ?>" enctype="multipart/form-data">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="title" name="title" value="<?php echo e(old('title', isset($ranking) ? $ranking->title : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="title" class="placeholder">Title <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <select class="input" id="year" name="year" required>
                            <option value="">Select Year</option>
                            <?php
                                $currentYear = date('Y');
                                $nextYear = $currentYear + 1;
                            ?>
                            
                            <?php for($i = $nextYear; $i >= ($currentYear - 40); $i--): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e(old('year', isset($ranking) && $ranking->year == $i ? 'selected' : '')); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                        <div class="cut"></div>
                        <label for="year" class="placeholder">Year <span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="url" class="input" id="link" name="link" value="<?php echo e(old('link', isset($ranking) ? $ranking->link : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="link" class="placeholder">Website Link <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="file" class="input border-0 pt-2" id="picture" name="picture" accept="image/*" <?php echo e(isset($ranking) ? '' : 'required'); ?>>
                        <?php if(isset($ranking) && $ranking->picture): ?>
                            <div class="mr-2 mt-3 float-right">
                                <img src="<?php echo e(asset('uploads/ranking/' . $ranking->picture)); ?>" alt="Image" height="auto" width="150">
                            </div>
                        <?php endif; ?>   
                        <div class="cut"></div>
                        <label for="picture" class="placeholder">Ranking Image<small class="font-italic"> (size: 300 x 150 px)</small> <span class="text-danger">*</span></label>
                    </div>
                </div>
                <?php if(isset($ranking)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('rankings.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="row d-block">
        <div class="mx-auto pt-5 pb-5">
            <h5 class="text-center mb-5">University Rankings</h5>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Year</th>
                            <th>Name of University Rankings</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rankings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$ranking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ranking->year); ?></td>
                                <td><a href="<?php echo e($ranking->link); ?>" target="_blank"><?php echo e($ranking->title); ?></a></td>
                                <td>
                                    <?php if($ranking->picture): ?>
                                        <img src="<?php echo e(asset('uploads/ranking/' . $ranking->picture)); ?>" alt="<?php echo e($ranking->title); ?> Image" width="150">
                                    <?php else: ?>
                                        No Image Available
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('rankings.edit', $ranking->id)); ?>" class="btn btn-sm text-primary"><i class="fas fa-edit fa-sm"></i></a>
                                    <form action="<?php echo e(route('rankings.destroy', $ranking->id)); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm text-danger" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/backend/ranking.blade.php ENDPATH**/ ?>