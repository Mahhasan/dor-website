
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($interdisciplinaryResearch)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Add New Research Lab">Add New Research Lab</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($interdisciplinaryResearch) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <?php if(isset($interdisciplinaryResearch)): ?>
                <h6>Edit <span class="text-success font-weight-bold"><?php echo e($interdisciplinaryResearch->lab_name); ?></span> Lab Record</h6>
                <form method="POST" action="<?php echo e(route('interdisciplinary.research.update', $interdisciplinaryResearch->id)); ?>" enctype="multipart/form-data">
                    <?php echo method_field('PATCH'); ?>
                <?php else: ?>
                    <h6>Add New Research Lab</h6>
                    <form method="POST" action="<?php echo e(route('interdisciplinary.research.store')); ?>" enctype="multipart/form-data">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container col-sm-6 mb-4">
                        <select class="input bg-white" id="discipline" name="discipline" required placeholder=" ">
                            <option value="">Select a discipline</option>
                            <option value="Interdisciplinary Research" <?php echo e(old('discipline', isset($interdisciplinaryResearch) ? $interdisciplinaryResearch->discipline : '') === 'Interdisciplinary Research' ? 'selected' : ''); ?>>Interdisciplinary Research</option>
                            <option value="Science Discipline" <?php echo e(old('discipline', isset($interdisciplinaryResearch) ? $interdisciplinaryResearch->discipline : '') === 'Science Discipline' ? 'selected' : ''); ?>>Science Discipline</option>
                        </select>
                        <div class="cut"></div>
                        <label for="discipline" class="placeholder">Discipline Name <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="url" class="input" id="link" name="link" value="<?php echo e(old('link', isset($interdisciplinaryResearch) ? $interdisciplinaryResearch->link : '')); ?>" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="link" class="placeholder">Website Link</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="lab_name" name="lab_name" value="<?php echo e(old('lab_name', isset($interdisciplinaryResearch) ? $interdisciplinaryResearch->lab_name : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="lab_name" class="placeholder">Lab Name <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="lab_number" name="lab_number" value="<?php echo e(old('lab_number', isset($interdisciplinaryResearch) ? $interdisciplinaryResearch->lab_number : '')); ?>" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="lab_number" class="placeholder">Lab Number</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-md-12 mb-4">
                        <input type="file" class="input border-0 pt-2" id="picture[]" name="picture[]" accept="image/*" multiple placeholder=" ">
                        <?php if(isset($interdisciplinaryResearch) && $interdisciplinaryResearch->picture): ?>
                            <div class="row existing-pictures float-right mt-3 ml-1 mr-1">
                                <?php $__currentLoopData = json_decode($interdisciplinaryResearch->picture, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="existing-picture mr-2 mb-2">
                                        <input type="checkbox" name="deleted_pictures[]" value="<?php echo e($picture); ?>">
                                        <img src="<?php echo e(asset('uploads/interdisciplinary_research/' . $picture)); ?>" alt="Image" height="75px" width="100">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <small class="font-italic">(If you want to remove an image then select it)</small>
                        <?php endif; ?>
                        <div class="cut"></div>
                        <label for="picture" class="placeholder">Lab Image <small class="font-italic">(size: 416 x 250 px)</small></label>
                    </div>
                </div>
                <div class="input-container col-md-12 mb-4 pr-0 pl-0">
                    <div class="additional-links">
                        <?php if(isset($interdisciplinaryResearch) && $interdisciplinaryResearch->image_links): ?>
                            <?php $__currentLoopData = json_decode($interdisciplinaryResearch->image_links, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row input-container mb-5">
                                    <div class="col-9 col-lg-10">
                                        <input type="url" class="input" id="link" name="image_links[]" value="<?php echo e(old('image_links.' . $index, $link)); ?>" placeholder=" "/>
                                        <div class="cut"></div>
                                        <label for="link" class="placeholder">Image Link <?php echo e($index + 1); ?></label>
                                        <iframe class="mt-3" src="<?php echo e($link); ?>" frameborder="0" height="auto" width="100%"></iframe>
                                    </div>
                                    <button type="button" class="col-3 col-lg-2 btn btn-outline-danger remove-link">Remove</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="btn btn-outline-info" id="add-link">Insert Lab Image Link  (if any)</button>
                </div>
                <label class="text-muted">Assigned Person Details</label>
                <div class="row mt-3">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="person_name" name="person_name" value="<?php echo e(old('person_name', isset($interdisciplinaryResearch) ? $interdisciplinaryResearch->person_name : '')); ?>" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="person_name" class="placeholder">Person Name</label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="designation" name="designation" value="<?php echo e(old('designation', isset($interdisciplinaryResearch) ? $interdisciplinaryResearch->designation : '')); ?>" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="designation" class="placeholder">Designation</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="number" class="input" id="cell" name="cell" value="<?php echo e(old('cell', isset($interdisciplinaryResearch) ? $interdisciplinaryResearch->cell : '')); ?>" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="cell" class="placeholder">Mobile No</label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="email" class="input" id="email" name="email" value="<?php echo e(old('email', isset($interdisciplinaryResearch) ? $interdisciplinaryResearch->email : '')); ?>" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="email" class="placeholder">Email</label>
                    </div>
                </div>
                <?php if(isset($interdisciplinaryResearch)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('interdisciplinary.research.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- Tabs -->
    <section id="tabs">
        <div class="row d-block">
            <div class="mx-auto pt-5 pb-5">
                <h5 class="text-center mb-5">Interdisciplinary Research Records</h5>
                <nav>
                    <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                        <a class="nav-item nav-link active" id="nav-fsit-tab" data-toggle="tab" href="#nav-fsit" role="tab" aria-controls="nav-fsit" aria-selected="true">Interdisciplinary Research</a>
                        <a class="nav-item nav-link" id="nav-fbe-tab" data-toggle="tab" href="#nav-fbe" role="tab" aria-controls="nav-fbe" aria-selected="false">Science Discipline</a>
                    </div>
                </nav>
                <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-fsit" role="tabpanel" aria-labelledby="nav-fsit-tab">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped" id="" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $interdiscipline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$discipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="text-center p-2">
                                                <h4><?php echo e(++$key); ?>. <?php echo e($discipline->lab_name); ?></h4>
                                                <p><a href="<?php echo e($discipline->link); ?>" target="_blank" class="text-decoration-none"><?php echo e($discipline->link); ?></a></p>
                                                <p><?php echo e($discipline->person_name); ?></p>
                                                <p><?php echo e($discipline->designation); ?></p>
                                                <p><?php echo e($discipline->cell); ?></p>
                                                <p><?php echo e($discipline->email); ?></p>
                                                <div class="text-center">
                                                    <a href="<?php echo e(route('interdisciplinary.research.edit', $discipline->id)); ?>" class="btn btn-sm text-primary"><i class="fas fa-edit fa-sm"></i></a>
                                                    <form action="<?php echo e(route('interdisciplinary.research.destroy', $discipline->id)); ?>" method="POST" style="display: inline;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm text-danger" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                                                    </form>
                                                </div>
                                            </div>
                                            <div>
                                                <?php if($discipline->picture): ?>
                                                    <?php $__currentLoopData = json_decode($discipline->picture, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <img src="<?php echo e(asset('uploads/interdisciplinary_research/' . $picture)); ?>" alt="Image Not Found" class="rounded pb-1" height="125px" width="208px">
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>

                                                <?php endif; ?>
                                                <?php if($discipline->image_links): ?>
                                                    <div class="existing-links">
                                                        <?php $__currentLoopData = json_decode($discipline->image_links, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <iframe class="p-2" src="<?php echo e($link); ?>" alt="Image Not Found" frameborder="0" height="180" width="260"></iframe>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php else: ?>
                                                    
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-fbe" role="tabpanel" aria-labelledby="nav-fbe-tab">
                        <div class="table-responsive">
                        <table class="table table-bordered table-hover table-striped" id="" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $sciencediscipline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$discipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td>
                                            <div class="text-center p-2">
                                                <h4><?php echo e(++$key); ?>. <?php echo e($discipline->lab_name); ?></h4>
                                                <p><a href="<?php echo e($discipline->link); ?>" target="_blank" class="text-decoration-none"><?php echo e($discipline->link); ?></a></p>
                                                <p><?php echo e($discipline->person_name); ?></p>
                                                <p><?php echo e($discipline->designation); ?></p>
                                                <p><?php echo e($discipline->cell); ?></p>
                                                <p><?php echo e($discipline->email); ?></p>
                                                <div class="text-center">
                                                    <a href="<?php echo e(route('interdisciplinary.research.edit', $discipline->id)); ?>" class="btn btn-sm text-primary"><i class="fas fa-edit fa-sm"></i></a>
                                                    <form action="<?php echo e(route('interdisciplinary.research.destroy', $discipline->id)); ?>" method="POST" style="display: inline;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm text-danger" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                                                    </form>
                                                </div>
                                            </div>
                                            <div>
                                                <?php if($discipline->picture): ?>
                                                    <?php $__currentLoopData = json_decode($discipline->picture, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <img src="<?php echo e(asset('uploads/interdisciplinary_research/' . $picture)); ?>" alt="<?php echo e($discipline->name); ?> Image" class="rounded pb-1" height="125px" width="208px">
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>

                                                <?php endif; ?>
                                                <?php if($discipline->image_links): ?>
                                                    <div class="existing-links">
                                                        <?php $__currentLoopData = json_decode($discipline->image_links, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <iframe class="p-2" src="<?php echo e($link); ?>" frameborder="0" height="180" width="260"></iframe>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php else: ?>
                                                    
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        // Add Link button click event
        $('#add-link').click(function () {
            var linkField = `
                <div class="row input-container mb-4">
                    <div class="col-8 col-lg-10">
                        <input type="url" class="input" name="image_links[]" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="link" class="placeholder">Image Link</label>
                    </div>
                    <button type="button" class="col-4 col-lg-2 btn btn-outline-danger remove-link">Remove</button>
                </div>
            `;
            $('.additional-links').append(linkField);
        });

        // Remove Link button click event
        $('.additional-links').on('click', '.remove-link', function () {
            $(this).closest('.input-container').remove();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/backend/interdisciplinary_research.blade.php ENDPATH**/ ?>