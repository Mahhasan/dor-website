
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($researchEthicsCommittee)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Add New Committee">Add New Committee</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($researchEthicsCommittee) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <h5>Research Ethics Committee</h5>
            <?php if(isset($researchEthicsCommittee)): ?>
                <h6>Edit <span class="text-success font-weight-bold"><?php echo e($researchEthicsCommittee->name); ?>'s</span> Record</h6>
                <form method="POST" action="<?php echo e(route('research.ethics.ommittees.update', $researchEthicsCommittee->id)); ?>">
                <?php echo method_field('PATCH'); ?>
            <?php else: ?>
                <h6>Add New Committee</h6>
                <form method="POST" action="<?php echo e(route('research.ethics.ommittees.store')); ?>">
            <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="name" name="name" value="<?php echo e(old('name', isset($researchEthicsCommittee) ? $researchEthicsCommittee->name : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="name" class="placeholder">Person Name <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="designation" name="designation" value="<?php echo e(old('designation', isset($researchEthicsCommittee) ? $researchEthicsCommittee->designation : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="designation" class="placeholder">Designation <span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-sm-6 mb-4">
                        <select id="department_id" class="input bg-white"  name="department_id" required placeholder=" ">
                            <option selected disabled>Select a Department</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>" <?php echo e(isset($researchEthicsCommittee) && $researchEthicsCommittee->department_id == $department->id ? 'selected' : ''); ?>><?php echo e($department->full_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="cut"></div>
                        <label for="department_id" class="placeholder">Department Name <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <select class="input bg-white" id="committee_name" name="committee_name" required>
                            <option value="">Select Committee</option>
                            <option value="FSIT Research Ethics Committee" <?php echo e(old('committee_name', isset($researchEthicsCommittee) ? $researchEthicsCommittee->committee_name : '') === 'FSIT Research Ethics Committee' ? 'selected' : ''); ?>>FSIT Research Ethics Committee</option>
                            <option value="FBE Research Ethics Committee" <?php echo e(old('committee_name', isset($researchEthicsCommittee) ? $researchEthicsCommittee->committee_name : '') === 'FBE Research Ethics Committee' ? 'selected' : ''); ?>>FBE Research Ethics Committee</option>
                            <option value="FAHS Research Ethics Committee" <?php echo e(old('committee_name', isset($researchEthicsCommittee) ? $researchEthicsCommittee->committee_name : '') === 'FAHS Research Ethics Committee' ? 'selected' : ''); ?>>FAHS Research Ethics Committee</option>
                            <option value="FE Research Ethics Committee" <?php echo e(old('committee_name', isset($researchEthicsCommittee) ? $researchEthicsCommittee->committee_name : '') === 'FE Research Ethics Committee' ? 'selected' : ''); ?>>FE Research Ethics Committee</option>
                            <option value="FHSS Research Ethics Committee" <?php echo e(old('committee_name', isset($researchEthicsCommittee) ? $researchEthicsCommittee->committee_name : '') === 'FHSS Research Ethics Committee' ? 'selected' : ''); ?>>FHSS Research Ethics Committee</option>
                        </select>
                        <div class="cut"></div>
                        <label for="committee_name" class="placeholder">Committee Name <span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="row">
                    <div class=" input-container col-sm-12 mb-4">
                        <input type="text" class="input" id="position" name="position" value="<?php echo e(old('position', isset($researchEthicsCommittee) ? $researchEthicsCommittee->position : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="position" class="placeholder">Position <span class="text-danger">*</span></label>
                    </div>
                </div>
                <?php if(isset($researchEthicsCommittee)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('research.ethics.ommittees.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <!-- Tabs -->
    <section id="tabs">
        <div class="row d-block">
            <div class="mx-auto pt-5 pb-5">
                <h5 class="text-center mt-5 mb-5">Research Ethics Committee Records</h5>
                <nav>
                    <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                        <a class="nav-item nav-link active" id="nav-fsit-tab" data-toggle="tab" href="#nav-fsit" role="tab" aria-controls="nav-fsit" aria-selected="true">FSIT</a>
                        <a class="nav-item nav-link" id="nav-fbe-tab" data-toggle="tab" href="#nav-fbe" role="tab" aria-controls="nav-fbe" aria-selected="false">FBE</a>
                        <a class="nav-item nav-link" id="nav-fahs-tab" data-toggle="tab" href="#nav-fahs" role="tab" aria-controls="nav-fahs" aria-selected="false">FAHS</a>
                        <a class="nav-item nav-link" id="nav-fe-tab" data-toggle="tab" href="#nav-fe" role="tab" aria-controls="nav-fe" aria-selected="false">FE</a>
                        <a class="nav-item nav-link" id="nav-fhss-tab" data-toggle="tab" href="#nav-fhss" role="tab" aria-controls="nav-fhss" aria-selected="false">FHSS</a>
                    </div>
                </nav>
                <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-fsit" role="tabpanel" aria-labelledby="nav-fsit-tab">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped" id="" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Name</th>
                                        <th>Designation</th>
                                        <th>Department</th>
                                        <th>Position</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $fsit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$committee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($committee->name); ?></td>
                                        <td><?php echo e($committee->designation); ?></td>
                                        <td><?php echo e($committee->departments->short_name ?? ''); ?></td>
                                        <td><?php echo e($committee->position); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('research.ethics.ommittees.edit', $committee->id)); ?>" class="btn text-primary" title="Edit <?php echo e($committee->name); ?>'s information"><i class="fas fa-edit fa-sm"></i></a>
                                            <form action="<?php echo e(route('research.ethics.ommittees.destroy', $committee->id)); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn text-danger" onclick="return confirm('Are you sure you want to delete this record?')" title="Delete <?php echo e($committee->name); ?>'s information"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-fbe" role="tabpanel" aria-labelledby="nav-fbe-tab">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped" id="" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Name</th>
                                        <th>Designation</th>
                                        <th>Department</th>
                                        <th>Position</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $fbe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$committee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($committee->name); ?></td>
                                        <td><?php echo e($committee->designation); ?></td>
                                        <td><?php echo e($committee->departments->short_name ?? ''); ?></td>
                                        <td><?php echo e($committee->position); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('research.ethics.ommittees.edit', $committee->id)); ?>" class="btn text-primary" title="Edit <?php echo e($committee->name); ?>'s information"><i class="fas fa-edit fa-sm"></i></a>
                                            <form action="<?php echo e(route('research.ethics.ommittees.destroy', $committee->id)); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn text-danger" onclick="return confirm('Are you sure you want to delete this record?')" title="Delete <?php echo e($committee->name); ?>'s information"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-fahs" role="tabpanel" aria-labelledby="nav-fahs-tab">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped" id="" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Name</th>
                                        <th>Designation</th>
                                        <th>Department</th>
                                        <th>Position</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $fahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$committee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($committee->name); ?></td>
                                        <td><?php echo e($committee->designation); ?></td>
                                        <td><?php echo e($committee->departments->short_name ?? ''); ?></td>
                                        <td><?php echo e($committee->position); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('research.ethics.ommittees.edit', $committee->id)); ?>" class="btn text-primary" title="Edit <?php echo e($committee->name); ?>'s information"><i class="fas fa-edit fa-sm"></i></a>
                                            <form action="<?php echo e(route('research.ethics.ommittees.destroy', $committee->id)); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn text-danger" onclick="return confirm('Are you sure you want to delete this record?')" title="Delete <?php echo e($committee->name); ?>'s information"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-fe" role="tabpanel" aria-labelledby="nav-fe-tab">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped" id="" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Name</th>
                                        <th>Designation</th>
                                        <th>Department</th>
                                        <th>Position</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $fe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$committee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($committee->name); ?></td>
                                        <td><?php echo e($committee->designation); ?></td>
                                        <td><?php echo e($committee->departments->short_name ?? ''); ?></td>
                                        <td><?php echo e($committee->position); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('research.ethics.ommittees.edit', $committee->id)); ?>" class="btn text-primary" title="Edit <?php echo e($committee->name); ?>'s information"><i class="fas fa-edit fa-sm"></i></a>
                                            <form action="<?php echo e(route('research.ethics.ommittees.destroy', $committee->id)); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn text-danger" onclick="return confirm('Are you sure you want to delete this record?')" title="Delete <?php echo e($committee->name); ?>'s information"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-fhss" role="tabpanel" aria-labelledby="nav-fhss-tab">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped" id="" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Name</th>
                                        <th>Designation</th>
                                        <th>Department</th>
                                        <th>Position</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $fhss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$committee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($committee->name); ?></td>
                                        <td><?php echo e($committee->designation); ?></td>
                                        <td><?php echo e($committee->departments->short_name ?? ''); ?></td>
                                        <td><?php echo e($committee->position); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('research.ethics.ommittees.edit', $committee->id)); ?>" class="btn text-primary" title="Edit <?php echo e($committee->name); ?>'s information"><i class="fas fa-edit fa-sm"></i></a>
                                            <form action="<?php echo e(route('research.ethics.ommittees.destroy', $committee->id)); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn text-danger" onclick="return confirm('Are you sure you want to delete this record?')" title="Delete <?php echo e($committee->name); ?>'s information"><i class="fa fa-trash fa-sm" aria-hidden="true"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/backend/research_ethics_committees.blade.php ENDPATH**/ ?>