
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Button to toggle form visibility -->
    <?php if(!isset($ourTeam)): ?>
        <button class="float-right btn btn-sm btn-primary" id="toggleForm" data-original-text="Add New Member">Add New Member</button>
    <?php endif; ?>
    <div class="row bg-aliceblue" id="FormContainer" style="display: <?php echo e(isset($ourTeam) ? 'block' : 'none'); ?>;">
        <div class="custom-form col-md-10 mx-auto pt-5 mb-5 pb-5">
            <?php if(isset($ourTeam)): ?>
            <h6>Edit <span class="text-success font-weight-bold"><?php echo e($ourTeam->name); ?>'s</span> Record</h6>
            <form method="POST" action="<?php echo e(route('our.team.update', $ourTeam->id)); ?>" enctype="multipart/form-data">
                <?php echo method_field('PATCH'); ?>
                <?php else: ?>
                <h6>Add New Member</h6>
            <form method="POST" action="<?php echo e(route('our.team.store')); ?>" enctype="multipart/form-data">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-5">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="name" name="name" value="<?php echo e(old('name', isset($ourTeam) ? $ourTeam->name : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="name" class="placeholder">Name <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="designation" name="designation" value="<?php echo e(old('designation', isset($ourTeam) ? $ourTeam->designation : '')); ?>" required placeholder=" "/>
                        <div class="cut"></div>
                        <label for="designation" class="placeholder">Designation <span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="email" class="input" id="email" name="email" value="<?php echo e(old('email', isset($ourTeam) ? $ourTeam->email : '')); ?>" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="email" class="placeholder">Email</label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="number" class="input" id="cell" name="cell" value="<?php echo e(old('cell', isset($ourTeam) ? $ourTeam->cell : '')); ?>" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="cell" class="placeholder">Cell</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-sm-6 mb-4">
                        <input type="text" class="input" id="department" name="department" value="<?php echo e(old('department', isset($ourTeam) ? $ourTeam->department : '')); ?>" placeholder=" "/>
                        <div class="cut"></div>
                        <label for="department" class="placeholder">Department</label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <select class="input bg-white" id="faculty_id" name="faculty_id" placeholder=" ">
                            <option value="">Select a Faculty</option>
                            <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($faculty->id); ?>" <?php echo e(isset($ourTeam) && $ourTeam->faculty_id == $faculty->id ? 'selected' : ''); ?>><?php echo e($faculty->full_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="cut"></div>
                        <label for="faculty_id" class="placeholder">Faculty Name</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-sm-6 mb-4" placeholder=" ">
                        <select class="input" id="level" name="level" required placeholder=" ">
                            <option value=""></option>
                            <option value="1" <?php echo e((isset($ourTeam) && $ourTeam->level == 1) ? 'selected' : ''); ?>>1 (Dean/Head)</option>
                            <option value="2" <?php echo e((isset($ourTeam) && $ourTeam->level == 2) ? 'selected' : ''); ?>>2 (Director)</option>
                            <option value="3" <?php echo e((isset($ourTeam) && $ourTeam->level == 3) ? 'selected' : ''); ?>>3 (Additional Director)</option>
                            <option value="4" <?php echo e((isset($ourTeam) && $ourTeam->level == 4) ? 'selected' : ''); ?>>4 (Joint Director)</option>
                            <option value="5" <?php echo e((isset($ourTeam) && $ourTeam->level == 5) ? 'selected' : ''); ?>>5 (Deputy Director)</option>
                            <option value="6" <?php echo e((isset($ourTeam) && $ourTeam->level == 6) ? 'selected' : ''); ?>>6 (Senior Asst. Director)</option>
                            <option value="7" <?php echo e((isset($ourTeam) && $ourTeam->level == 7) ? 'selected' : ''); ?>>7 (Assistant Director)</option>
                            <option value="8" <?php echo e((isset($ourTeam) && $ourTeam->level == 8) ? 'selected' : ''); ?>>8 (Officer/Others)</option>
                        </select>
                        <div class="cut"></div>
                        <label for="level" class="placeholder">Priority Level <span class="text-danger">*</span></label>
                    </div>
                    <div class="input-container col-sm-6 mb-4">
                        <input type="file" class="input border-0 pt-2" id="picture" name="picture" accept="image/*" placeholder=" "<?php echo e(isset($ourTeam) ? '' : 'required'); ?>>
                        <?php if(isset($ourTeam) && $ourTeam->picture): ?>
                            <div class="mt-3 float-right">
                                <img src="<?php echo e(asset('uploads/our_team/' . $ourTeam->picture)); ?>" alt="Image" height="auto" width="200">
                            </div>
                        <?php endif; ?>
                        <div class="cut"></div>
                        <label for="picture" class="placeholder">Image <small class="font-italic">(size: 150 x 150 px)</small> <span class="text-danger">*</span></label>
                    </div>
                </div>
                <?php if(isset($ourTeam)): ?>
                    <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('our.team.index')); ?>" class="btn btn-sm btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="mx-auto mb-5">
        <h5 class="text-center pt-5">Our Team</h5>
        <hr>
    </div>

    <div class="pb-5">
        <?php for($level = 1; $level <= 8; $level++): ?>
            <?php if($ourTeams->where('level', $level)->count() > 0): ?>
                <div class="row">
                    <?php $__currentLoopData = $ourTeams->where('level', $level); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ourTeam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-4 mx-auto">
                            <div class="card border-0">
                                <?php if($ourTeam->picture): ?>
                                    <div class="text-center mt-3">
                                        <img src="<?php echo e(asset('uploads/our_team/' . $ourTeam->picture)); ?>" class="rounded-circle" alt="<?php echo e($ourTeam->name); ?> Image" height="150" width="150">
                                    </div>
                                <?php else: ?>
                                    <div class="text-center mt-3">
                                        <img src="<?php echo e(asset('frontend/images/path_to_default_image.jpg')); ?>" class="rounded-circle" alt="No Image Available" height="150" width="150">
                                    </div>
                                <?php endif; ?>
                                <div class="text-center p-1">
                                    <h5><?php echo e($ourTeam->name); ?></h5>
                                    <p><?php echo e($ourTeam->designation); ?>, <?php echo e($ourTeam->department); ?></p>
                                    <p><?php echo e($ourTeam->faculties->short_name ?? ''); ?></p>
                                    <p><?php echo e($ourTeam->email); ?></p>
                                    <p><?php echo e($ourTeam->cell); ?></p>
                                    <div class="float-right">
                                        <a href="<?php echo e(route('our.team.edit', $ourTeam->id)); ?>" class="btn btn-sm text-primary"><i class="fas fa-edit"></i></a>
                                        <form action="<?php echo e(route('our.team.destroy', $ourTeam->id)); ?>" method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm text-danger" onclick="return confirm('Are you sure you want to delete this record?')"><i class="fa fa-trash"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        <?php endfor; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/backend/our_team.blade.php ENDPATH**/ ?>