<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
        <div class="row">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">Sl. No</th>
                        <th scope="col">Research Collaboration with Universities</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($collaboratingResearches)): ?>
                        <?php $__currentLoopData = $collaboratingResearches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$collaboratingResearch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e(++$key); ?></th>
                                <td><?php echo e($collaboratingResearch->institute_name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/frontend/research-collaboration.blade.php ENDPATH**/ ?>