<?php $__env->startSection('content'); ?>

<!-- Search Filters -->
<div class="row mb-4">
  <div class="col-md-3">
    <label for="facultySelect">
      <small class="fw-bold search-text">
        <i class="fas fa-search"></i> Search by Faculty
      </small>
    </label>
    <select class="form-select" id="facultySelect" onchange="filterProfiles()">
      <option value="">Select Faculty</option>
      <option value="Faculty of Science and Information Technology">FSIT</option>
      <option value="Faculty of Engineering">FE</option>
      <option value="Faculty of Business and Entrepreneurship">FBE</option>
      <option value="Faculty of Humanities and Social Sciences">FHSS</option>
      <option value="Faculty of Health and Life Sciences">FHLS</option>
      <option value="Faculty of Graduate Studies">FGS</option>
    </select>
  </div>

  <div class="col-md-3">
    <label for="departmentSelect">
      <small class="fw-bold search-text">
        <i class="fas fa-search"></i> Search by Department
      </small>
    </label>
    <select class="form-select" id="departmentSelect" onchange="filterProfiles()">
      <option value="">Select Department</option>
    </select>
  </div>

  <div class="col-md-3">
    <label for="expertiseSearch">
      <small class="fw-bold search-text">
        <i class="fas fa-search"></i> Search by Expertise Area
      </small>
    </label>
    <input
      type="text"
      class="form-control"
      id="expertiseSearch"
      list="expertiseSuggestions"
      placeholder="Search by expertise"
      oninput="debouncedFilterProfiles()"
    />
    <datalist id="expertiseSuggestions"></datalist>
  </div>

  <div class="col-md-3">
    <label for="nameSearch">
      <small class="fw-bold search-text">
        <i class="fas fa-search"></i> Search by Researcher Name
      </small>
    </label>
    <input
      type="text"
      class="form-control"
      id="nameSearch"
      list="nameSuggestions"
      placeholder="Search by researcher name"
      oninput="debouncedFilterProfiles()"
    />
    <datalist id="nameSuggestions"></datalist>
  </div>
</div>

<div class="text-center py-5 d-none">
  <img src="<?php echo e(asset('rp-img/no-result-found.jpg')); ?>" class="rounded img-fluid" alt="no-result-found-img" />
  <br>
  <!-- Refresh Button -->
  <button class="btn btn-primary mt-3" onclick="window.location.reload();">
    <i class="fa fa-refresh" aria-hidden="true"></i> Refresh
  </button>
</div>

<!-- Researcher Profile Cards -->
<div class="card-container" id="profileContainer"></div>

<!-- Pagination -->
<div class="pagination-container py-3">
  <nav>
    <ul class="pagination" id="pagination"></ul>
  </nav>
</div>

<script>
  let currentPage = 1;
  const profilesPerPage = 6;
  let researchers = [];
  let filteredResearchers = [];

  // Go to a specific page
  function goToPage(page) {
    currentPage = page;
    renderProfiles(currentPage);
    setupPagination();
  }

  // Debounce utility function
  function debounce(func, delay) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => func.apply(this, args), delay);
    };
  }

  // Debounced version of filterProfiles
const debouncedFilterProfiles = debounce(filterProfiles, 300); // 300ms delay

// Attach the debounced function to inputs
document.getElementById("expertiseSearch").addEventListener("input", debouncedFilterProfiles);
document.getElementById("nameSearch").addEventListener("input", debouncedFilterProfiles);

  // Fetch researchers data from the JSON file and initialize the display
  fetch("rp-js/researchers.json")
    .then((response) => response.json())
    .then((data) => {
      researchers = data;
      populateExpertiseSuggestions();
      populateNameSuggestions();
      shuffleArray(researchers);
      filteredResearchers = [...researchers];
      filterProfiles(); // Render profiles after fetching data
    })
    .catch((error) => console.error("Error loading JSON data:", error));

  // Shuffle array function
  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  // Go to a specific page
  function goToPage(page) {
    currentPage = page;
    renderProfiles(currentPage);
    setupPagination();
  }

  // Render profiles based on the current page and filtered data
  function renderProfiles(page) {
    const profileContainer = document.getElementById("profileContainer");
    const noResultDiv = document.querySelector(".text-center.py-5");
    profileContainer.innerHTML = "";

    const startIndex = (page - 1) * profilesPerPage;
    const endIndex = startIndex + profilesPerPage;
    const profilesToDisplay = filteredResearchers.slice(startIndex, endIndex);

    if (profilesToDisplay.length === 0) {
      noResultDiv.classList.remove("d-none");
    } else {
      noResultDiv.classList.add("d-none");
      profilesToDisplay.forEach((profile) => {
        const expertiseButtons = profile.expertise
          .map(
            (expertise) =>
              `<button class="btn btn-sm btn-outline-primary m-1">${expertise}</button>`
          )
          .join("");

        const profileButtons = `
          ${
            profile.diuPortfolio
              ? `<a href="${profile.diuPortfolio}" class="btn btn-sm btn-primary m-1" target="_blank"><i class="fa-solid fa-globe"></i> DIU Portfolio</a>`
              : ""
          }
          ${
            profile.orcidProfile
              ? `<a href="${profile.orcidProfile}" class="btn btn-sm btn-primary m-1" target="_blank"><i class="fa-brands fa-orcid"></i> ORCID</a>`
              : ""
          }
          ${
            profile.scopusProfile
              ? `<a href="${profile.scopusProfile}" class="btn btn-sm btn-primary m-1" target="_blank"><i class="fa-solid fa-globe"></i> Scopus</a>`
              : ""
          }
          ${
            profile.googleSite
              ? `<a href="${profile.googleSite}" class="btn btn-sm btn-primary m-1" target="_blank"><i class="fa-brands fa-google"></i> Google Scholar</a>`
              : ""
          }
          ${
            profile.wosProfile
              ? `<a href="${profile.wosProfile}" class="btn btn-sm btn-primary m-1" target="_blank"><i class="fa-solid fa-globe"></i> WoS</a>`
              : ""
          }
        `;

        const profileCard = `
          <div class="card mx-auto">
              <div class="card-body text-center">
                <div class="card-header">
                  <a href="/researchers/${profile.departmentSF}/${profile.slug}">
                    <img 
                      src="${profile.image}" 
                      alt="${profile.name}" 
                      class="profile-image mx-auto d-block" 
                    />
                  </a>
                  <h5 class="card-title mt-3 mb-0">
                    <a class="text-primary" style="text-decoration:none;" href="/researchers/${profile.departmentSF}/${profile.slug}">${profile.name}</a>
                  </h5>
                  <small class="card-text">${profile.designation}</small>
                  <p class="card-text mt-3">${profile.department}, ${profile.faculty}</p>
                </div>
                <div>${profileButtons}</div>
                <hr>
                <p class="card-text text-start text-primary"><strong>Area of Expertise</strong></p>
                <hr style="width: 5%; height: 3px; color: #034ea2; background-color: #034ea2 !important; opacity: 1; margin-top: -12px;"> 
                <div class="d-flex flex-wrap justify-content-start">
                  ${expertiseButtons}
                </div>
              </div>
              <div class="card-footer text-center">
                  <a class="text-primary" style="text-decoration: none;" href="/researchers/${profile.departmentSF}/${profile.slug}"><i class="fa fa-eye" aria-hidden="true"></i> View Details</a>
                </div>
            </div>
        `;
        profileContainer.insertAdjacentHTML("beforeend", profileCard);
      });
    }
  }

  function setupPagination() {
    const pagination = document.getElementById("pagination");
    pagination.innerHTML = "";

    const totalPages = Math.ceil(filteredResearchers.length / profilesPerPage);
    if (totalPages <= 1) return;

    // Add "Prev" button
    pagination.insertAdjacentHTML(
      "beforeend",
      `<li class="page-item ${currentPage === 1 ? "disabled" : ""}">
        <button class="page-link" onclick="goToPage(${
          currentPage - 1
        })">Prev</button>
      </li>`
    );

    // Calculate page numbers to show
    const maxPagesToShow = 5; // Maximum visible pages
    const halfMaxPages = Math.floor(maxPagesToShow / 2);
    let startPage = Math.max(1, currentPage - halfMaxPages);
    let endPage = Math.min(totalPages, currentPage + halfMaxPages);

    // Ensure consistent number of pages if possible
    if (currentPage <= halfMaxPages) {
      endPage = Math.min(totalPages, maxPagesToShow);
    } else if (currentPage >= totalPages - halfMaxPages) {
      startPage = Math.max(1, totalPages - maxPagesToShow + 1);
    }

    if (startPage > 1) {
      pagination.insertAdjacentHTML(
        "beforeend",
        `<li class="page-item">
          <button class="page-link" onclick="goToPage(1)">1</button>
        </li>
        <li class="page-item disabled">
          <span class="page-link">...</span>
        </li>`
      );
    }

    for (let i = startPage; i <= endPage; i++) {
      pagination.insertAdjacentHTML(
        "beforeend",
        `<li class="page-item ${i === currentPage ? "active" : ""}">
          <button class="page-link" onclick="goToPage(${i})">${i}</button>
        </li>`
      );
    }

    if (endPage < totalPages) {
      pagination.insertAdjacentHTML(
        "beforeend",
        `<li class="page-item disabled">
          <span class="page-link">...</span>
        </li>
        <li class="page-item">
          <button class="page-link" onclick="goToPage(${totalPages})">${totalPages}</button>
        </li>`
      );
    }

    // Add "Next" button
    pagination.insertAdjacentHTML(
      "beforeend",
      `<li class="page-item ${currentPage === totalPages ? "disabled" : ""}">
        <button class="page-link" onclick="goToPage(${
          currentPage + 1
        })">Next</button>
      </li>`
    );
  }


  function populateExpertiseSuggestions() {
    const expertiseSet = new Set();

    // Collect unique expertise values (case-insensitive) from researchers
    researchers.forEach((profile) => {
      if (profile.expertise && Array.isArray(profile.expertise)) {
        profile.expertise.forEach(
          (exp) => expertiseSet.add(exp.trim().toLowerCase()) // Normalize to lowercase
        );
      }
    });

    // Store all sorted suggestions in a data attribute
    const expertiseSuggestions = document.getElementById("expertiseSuggestions");
    expertiseSuggestions.dataset.allSuggestions = JSON.stringify(
      Array.from(expertiseSet).sort()
    );
  }

  // Show filtered suggestions dynamically based on user input
  document
    .getElementById("expertiseSearch")
    .addEventListener("input", function () {
      const input = this.value.trim().toLowerCase(); // Normalize input
      const expertiseSuggestions = document.getElementById(
        "expertiseSuggestions"
      );

      // Retrieve stored suggestions
      const allSuggestions = JSON.parse(
        expertiseSuggestions.dataset.allSuggestions || "[]"
      );

      // Filter and limit to 5 unique suggestions
      const filteredSuggestions = Array.from(
        new Set(
          allSuggestions.filter(
            (expertise) => expertise.includes(input) && input.length > 0 // Case-insensitive match
          )
        )
      ).slice(0, 5);

      // Update the datalist with filtered suggestions
      expertiseSuggestions.innerHTML = filteredSuggestions
        .map(
          (expertise) =>
            `<option value="${
              expertise.charAt(0).toUpperCase() + expertise.slice(1)
            }">` // Capitalize the first letter
        )
        .join("");
    });

  function populateNameSuggestions() {
    const nameSet = new Set();

    // Collect unique names (case-insensitive) from researchers
    researchers.forEach((profile) => {
      if (profile.name) {
        nameSet.add(profile.name.trim().toLowerCase()); // Normalize to lowercase
      }
    });

    // Store all sorted suggestions in a data attribute
    const nameSuggestions = document.getElementById("nameSuggestions"); // Correctly reference unique datalist
    nameSuggestions.dataset.allSuggestions = JSON.stringify(
      Array.from(nameSet).sort()
    );
  }

  // Show filtered suggestions dynamically for names
  document.getElementById("nameSearch").addEventListener("input", function () {
    const input = this.value.trim().toLowerCase(); // Normalize input
    const nameSuggestions = document.getElementById("nameSuggestions");

    // Retrieve stored suggestions
    const allSuggestions = JSON.parse(
      nameSuggestions.dataset.allSuggestions || "[]"
    );

    // Filter and limit to 5 unique suggestions
    const filteredSuggestions = Array.from(
      new Set(
        allSuggestions.filter(
          (name) => name.includes(input) && input.length > 0 // Case-insensitive match
        )
      )
    ).slice(0, 5);

    // Update the datalist with filtered suggestions
    nameSuggestions.innerHTML = filteredSuggestions
      .map(
        (name) =>
          `<option value="${name.charAt(0).toUpperCase() + name.slice(1)}">` // Capitalize the first letter
      )
      .join("");
  });

  // Filtering function
  function filterProfiles() {
    const faculty = document.getElementById("facultySelect").value;
    const department = document.getElementById("departmentSelect").value;
    const expertise = document.getElementById("expertiseSearch").value.trim().replace(/\s+/g, " ").toLowerCase();
    const name = document.getElementById("nameSearch").value.trim().replace(/\s+/g, " ").toLowerCase();

    filteredResearchers = researchers.filter((profile) => {
        return (!faculty || profile.faculty === faculty) &&
               (!department || profile.department === department) &&
               (!expertise || profile.expertise.some((exp) => exp.toLowerCase().includes(expertise))) &&
               (!name || profile.name.toLowerCase().includes(name));
    });

    currentPage = 1; // Reset to first page when filters change
    renderProfiles(currentPage);
    setupPagination();
  }

  // Update department options based on selected faculty
  document.getElementById("facultySelect").addEventListener("change", function () {
    const faculty = this.value;
    const departmentSelect = document.getElementById("departmentSelect");
    departmentSelect.innerHTML = '<option value="">Select Department</option>'; // Reset the department options

    // Define departments for each faculty
    const departments = {
      "Faculty of Science and Information Technology": [
        "Department of Computer Science and Engineering",
        "Department of Software Engineering",
        "Department of Multimedia and Creative Technology",
        "Department of Computing and Information System",
        "Department of Information Technology and Management",
      ],
      "Faculty of Engineering": [
        "Department of Information and Communication Engineering",
        "Department of Textile Engineering",
        "Department of Electrical and Electronic Engineering",
        "Department of Architecture",
        "Department of Civil Engineering",
      ],
      "Faculty of Business and Entrepreneurship": [
        "Department of Business Administration",
        "Department of Management",
        "Department of Real Estate",
        "Department of Tourism and Hospitality Management",
        "Department of Innovation and Entrepreneurship",
        "Department of Accounting",
        "Department of Finance and Banking",
        "Department of Marketing",
      ],
      "Faculty of Humanities and Social Sciences": [
        "Department of English",
        "Department of Law",
        "Department of Journalism, Media and Communication",
        "Department of Development Studies",
      ],
      "Faculty of Health and Life Sciences": [
        "Department of Environmental Science and Disaster Management",
        "Department of Pharmacy",
        "Department of Nutrition and Food Engineering",
        "Department of Public Health",
        "Department of Physical Education and Sports Science",
        "Department of Agricultural Science",
      ],
      "Faculty of Graduate Studies": [
        "Faculty of Graduate Studies"
      ]
    };

    // Populate department options based on selected faculty
    (departments[faculty] || []).forEach((dept) => {
      const option = document.createElement("option");
      option.value = dept;
      option.textContent = dept;
      departmentSelect.appendChild(option);
    });

    // Trigger filter after department options are populated
    filterProfiles(); // Re-filter profiles when faculty or department is selected
  });

  // Filter profiles when department is selected
  document.getElementById("departmentSelect").addEventListener("change", function () {
    filterProfiles(); // Apply filter when department changes
  });

  // Initial filtering and rendering
  filterProfiles();
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('rplayouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/researchers.blade.php ENDPATH**/ ?>