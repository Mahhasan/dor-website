<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
        <div class="row">
            <h5 class="text-center mt-5 mb-5">Research Coordinator</h5>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">Sl.</th>
                        <th scope="col">Research Coordinator</th>
                        <th scope="col">Particulars</th>
                        <th scope="col">Department</th>
                        <th scope="col">Faculty</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $serialNumber = 1; ?>
                    <?php $__currentLoopData = $groupedCoordinators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facultyId => $facultyCoordinators): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $facultyCoordinators->groupBy('department_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departmentId => $departmentCoordinators): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $departmentRowCount = count($departmentCoordinators);
                            ?>
                            <?php $__currentLoopData = $departmentCoordinators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $researchCoordinator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($serialNumber++); ?></td>
                                    <td><?php echo e($researchCoordinator->name); ?></td>
                                    <td><?php echo e($researchCoordinator->designation); ?><br>
                                        <?php echo e($researchCoordinator->email); ?><br>
                                        <?php echo e($researchCoordinator->cell); ?>

                                    </td>
                                    <?php if($key === 0): ?>
                                        <td rowspan="<?php echo e($departmentRowCount); ?>"><?php echo e($researchCoordinator->departments->short_name ?? ''); ?></td>
                                        <td rowspan="<?php echo e($departmentRowCount); ?>"><?php echo e($researchCoordinator->faculties->short_name ?? ''); ?></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/frontend/research_coordinator.blade.php ENDPATH**/ ?>