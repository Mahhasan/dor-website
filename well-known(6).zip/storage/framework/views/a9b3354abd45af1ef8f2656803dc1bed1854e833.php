<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
		<div class="row">
			<div class="col-sm-12 col-xs-12">
				<div class="image-content">
					<?php if(isset($resources)): ?>
						<?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="section-title text-center mb-4">
								<h3><?php echo e($resource->topic); ?></h3>
							</div>
							<div class="row">
								<?php if(pathinfo($resource->document, PATHINFO_EXTENSION) == 'pdf'): ?>
									<iframe src="<?php echo e(asset('uploads/resource/' . $resource->document)); ?>" width="100%" height="700"></iframe>
								<?php else: ?>
									<img src="<?php echo e(asset('uploads/resource/' . $resource->document)); ?>" alt="No Resource Available" width="100%">
								<?php endif; ?>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/frontend/resource_details.blade.php ENDPATH**/ ?>