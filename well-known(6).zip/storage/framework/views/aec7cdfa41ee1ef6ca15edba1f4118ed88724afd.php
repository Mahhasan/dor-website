<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $research_Updates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $researchUpdate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3 class="text-center mb-4">Research Update (<?php echo e($researchUpdate->volume); ?>)</h3><br>
                <iframe src="<?php echo e(asset('uploads/research_update/' . $researchUpdate->file)); ?>" width="100%" height="700px"></iframe>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/frontend/research_update.blade.php ENDPATH**/ ?>