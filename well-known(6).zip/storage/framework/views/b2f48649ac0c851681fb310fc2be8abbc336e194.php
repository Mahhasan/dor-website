<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="icon" href="https://daffodilvarsity.edu.bd/images/diu/favicon.ico" type="image/gif">
        
        <!-- SEO Meta Tags -->
        <title><?php echo e(config('app.name', 'Division of Research')); ?></title>
        
        <!-- Description -->
        <meta name="description" content="The Division of Research at DIU fosters research excellence, innovation, and interdisciplinary collaboration across various fields.">
    
        <!-- Keywords -->
        <meta name="keywords" content="Division of Research, DIU, research excellence, DIU research, academic research, interdisciplinary collaboration, research innovation, Daffodil International University">
    
        <!-- Author -->
        <meta name="author" content="Division of Research, Daffodil International University">
    
        <!-- Open Graph Tags for Social Media -->
        <meta property="og:title" content="Division of Research - DIU">
        <meta property="og:description" content="The Division of Research at DIU fosters research excellence, innovation, and interdisciplinary collaboration across various fields.">
        <meta property="og:image" content="<?php echo e(asset('rp-img/diu.jpg')); ?>">
        <meta property="og:url" content="<?php echo e(url('/')); ?>">
        <meta property="og:type" content="website">
        
        <!-- Twitter Cards for Social Media -->
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="Division of Research - DIU">
        <meta name="twitter:description" content="The Division of Research at DIU fosters research excellence, innovation, and interdisciplinary collaboration across various fields.">
        <meta name="twitter:image" content="<?php echo e(asset('rp-img/diu.jpg')); ?>">
        <meta name="twitter:url" content="<?php echo e(url('/')); ?>">
        <!--Favicon-->
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
        <!-- Slick Carousel -->
        <link rel="stylesheet" href="<?php echo e(asset('js/slick/slick.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('js/slick/slick-theme.css')); ?>">
        <!-- FancyBox -->
        <link rel="stylesheet" href="<?php echo e(asset('js/fancybox/jquery.fancybox.min.css')); ?>">
        <link src="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" rel="stylesheet">
        <!-- Stylesheets -->
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
        
    </head>
    <body>
        <div class="page-wrapper">
            <?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>

            
        </div>
        <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
        <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/slick/slick.min.js')); ?>"></script>
        <!-- FancyBox -->
        <script src="<?php echo e(asset('js/fancybox/jquery.fancybox.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/validate.js')); ?>"></script>
        <script src="<?php echo e(asset('js/wow.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
        <script src="<?php echo e(asset('js/script.js')); ?>"></script>
        <script src="<?php echo e(asset('js/mouse.js')); ?>"></script>
    </body>

</html>
<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/frontend/layouts/master.blade.php ENDPATH**/ ?>