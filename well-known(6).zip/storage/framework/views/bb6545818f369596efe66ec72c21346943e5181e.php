<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
        <h3 class="text-center">Our <span>Team</span></h3>
        <hr>
        <p class="text-center"><span>Division of Research</span></p>
        <?php for($level = 1; $level <= 8; $level++): ?>
            <?php if($ourTeams->where('level', $level)->count() > 0): ?>
                <div class="row justify-content-center mb-2">
                    <?php $__currentLoopData = $ourTeams->where('level', $level); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ourTeam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-10 col-md-3 user">
                            <div class="team-person">
                                <?php if($ourTeam->picture): ?>
                                    <img src="<?php echo e(asset('uploads/our_team/' . $ourTeam->picture)); ?>" class="mx-auto" alt="">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('frontend/images/path_to_default_image.jpg')); ?>" class="mx-auto" alt="">
                                <?php endif; ?>
                                <h6><?php echo e($ourTeam->name); ?></h6>
                                <h6><?php echo e($ourTeam->designation); ?>, 
                                    <?php if($ourTeam->department): ?>
                                        <?php echo e($ourTeam->department); ?>,
                                    <?php endif; ?> 
                                    <?php echo e($ourTeam->faculties->short_name ?? ''); ?></h6>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        <?php endfor; ?>
        <hr>

        <div class="row justify-content-center">
            <p class="text-center mb-4"><span>Discipline Wise Research Coordinator</span></p>
            <!-- This section will be deleted -->
            <div class="col-10 col-sm-6 col-lg-4 col-xl-3 user_one">
                <div class="team-person">
                    <img src="images/team/bikash-swe.jpeg" alt="..." class="mx-auto">
                    <h6>Ms. Bikash Kumar Paul</h6>
                    <h6>Research Mentor</h6>
                </div>
            </div>
            <!-- end section -->
            <?php $__currentLoopData = $researchCoordinators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$researchCoordinator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-10 col-sm-6 col-lg-4 col-xl-3 user_one">
                    <div class="team-person">
                        <?php if($researchCoordinator->picture): ?>
                            <img src="<?php echo e(asset('uploads/research_coordinator/' . $researchCoordinator->picture)); ?>" class="mx-auto" alt="">
                        <?php else: ?>
                            No Image Available
                        <?php endif; ?>
                        <h6><?php echo e($researchCoordinator->name); ?></h6>
                        <h6><?php echo e($researchCoordinator->designation); ?>, <?php echo e($researchCoordinator->departments->short_name ?? ''); ?></h6>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/researchdaffodil/public_html/resources/views/frontend/our_team.blade.php ENDPATH**/ ?>