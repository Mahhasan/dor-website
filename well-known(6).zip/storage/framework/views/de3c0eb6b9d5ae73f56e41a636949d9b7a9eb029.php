<?php echo e($slot); ?>

<?php /**PATH /home/researchdaffodil/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>