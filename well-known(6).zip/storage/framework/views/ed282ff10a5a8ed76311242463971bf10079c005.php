
<?php $__env->startSection('content'); ?>
<section class="cta">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-primary">
                    <div class="panel-heading" style="font-family:Century Gothic;"><b><?php echo e($event->title); ?> - <?php echo e($event->year); ?></b></div>
                    <div class="panel-body"><?php echo $event->event_details; ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dor-website\resources\views/frontend/event_details.blade.php ENDPATH**/ ?>